.include "macros.s.inc"

.section .rodata


.global sUnk_8283F14
sUnk_8283F14:

baserom_blob 0x283F14, 0x283F54

.global sUnk_8283F54
sUnk_8283F54:

baserom_blob 0x283F54, 0x2844B8

.global sUnk_82844B8
sUnk_82844B8:

baserom_blob 0x2844B8, 0x2844EE

.global sUnk_82844EE
sUnk_82844EE:

baserom_blob 0x2844EE, 0x2844FC

.global sUnk_82844FC
sUnk_82844FC:

baserom_blob 0x2844FC, 0x28455C

.global sUnk_828455C
sUnk_828455C:

baserom_blob 0x28455C, 0x28566C

.global sUnk_828566C
sUnk_828566C:

baserom_blob 0x28566C, 0x2856DE

.global sUnk_82856DE
sUnk_82856DE:

baserom_blob 0x2856DE, 0x28588C

.global sUnk_828588C
sUnk_828588C:

baserom_blob 0x28588C, 0x285A40

.global sUnk_8285A40
sUnk_8285A40:

baserom_blob 0x285A40, 0x285C08

.global sUnk_8285C08
sUnk_8285C08:

baserom_blob 0x285C08, 0x285C10

.global sUnk_8285C10
sUnk_8285C10:

baserom_blob 0x285C10, 0x285C1E

.global sUnk_8285C1E
sUnk_8285C1E:

baserom_blob 0x285C1E, 0x285C32

.global sUnk_8285C32
sUnk_8285C32:

baserom_blob 0x285C32, 0x285C4C

.global sUnk_8285C4C
sUnk_8285C4C:

baserom_blob 0x285C4C, 0x285C6C

.global sUnk_8285C6C
sUnk_8285C6C:

baserom_blob 0x285C6C, 0x285C92

.global sUnk_8285C92
sUnk_8285C92:

baserom_blob 0x285C92, 0x285CBE

.global sUnk_8285CBE
sUnk_8285CBE:

baserom_blob 0x285CBE, 0x285CF0

.global sUnk_8285CF0
sUnk_8285CF0:

baserom_blob 0x285CF0, 0x285D28

.global sUnk_8285D28
sUnk_8285D28:

baserom_blob 0x285D28, 0x285D66

.global sUnk_8285D66
sUnk_8285D66:

baserom_blob 0x285D66, 0x285DAA

.global sUnk_8285DAA
sUnk_8285DAA:

baserom_blob 0x285DAA, 0x285DF4

.global sUnk_8285DF4
sUnk_8285DF4:

baserom_blob 0x285DF4, 0x285E44

.global sUnk_8285E44
sUnk_8285E44:

baserom_blob 0x285E44, 0x285E9A

.global sUnk_8285E9A
sUnk_8285E9A:

baserom_blob 0x285E9A, 0x285EF6

.global sUnk_8285EF6
sUnk_8285EF6:

baserom_blob 0x285EF6, 0x285F58

.global sUnk_8285F58
sUnk_8285F58:

baserom_blob 0x285F58, 0x285F60

.global sUnk_8285F60
sUnk_8285F60:

baserom_blob 0x285F60, 0x285F68

.global sUnk_8285F68
sUnk_8285F68:

baserom_blob 0x285F68, 0x285F76

.global sUnk_8285F76
sUnk_8285F76:

baserom_blob 0x285F76, 0x285F7E

.global sUnk_8285F7E
sUnk_8285F7E:

baserom_blob 0x285F7E, 0x285F8C

.global sUnk_8285F8C
sUnk_8285F8C:

baserom_blob 0x285F8C, 0x285F9A

.global sUnk_8285F9A
sUnk_8285F9A:

baserom_blob 0x285F9A, 0x285FAE

.global sUnk_8285FAE
sUnk_8285FAE:

baserom_blob 0x285FAE, 0x285FCC

.global sUnk_8285FCC
sUnk_8285FCC:

baserom_blob 0x285FCC, 0x28602C

.global sUnk_828602C
sUnk_828602C:

baserom_blob 0x28602C, 0x2873E4

.global sUnk_82873E4
sUnk_82873E4:

baserom_blob 0x2873E4, 0x287472

.global sUnk_8287472
sUnk_8287472:

baserom_blob 0x287472, 0x28759C

.global sUnk_828759C
sUnk_828759C:

baserom_blob 0x28759C, 0x287758

.global sUnk_8287758
sUnk_8287758:

baserom_blob 0x287758, 0x2877B8

.global sUnk_82877B8
sUnk_82877B8:

baserom_blob 0x2877B8, 0x288C48

.global sUnk_8288C48
sUnk_8288C48:

baserom_blob 0x288C48, 0x288D2E

.global sUnk_8288D2E
sUnk_8288D2E:

baserom_blob 0x288D2E, 0x288E28

.global sUnk_8288E28
sUnk_8288E28:

baserom_blob 0x288E28, 0x288E3A

.global sUnk_8288E3A
sUnk_8288E3A:

baserom_blob 0x288E3A, 0x288E48

.global sUnk_8288E48
sUnk_8288E48:

baserom_blob 0x288E48, 0x288E5A

.global sUnk_8288E5A
sUnk_8288E5A:

baserom_blob 0x288E5A, 0x288E6C

.global sUnk_8288E6C
sUnk_8288E6C:

baserom_blob 0x288E6C, 0x288EAC

.global sUnk_8288EAC
sUnk_8288EAC:

baserom_blob 0x288EAC, 0x288FCC

.global sUnk_8288FCC
sUnk_8288FCC:

baserom_blob 0x288FCC, 0x289026

.global sUnk_8289026
sUnk_8289026:

baserom_blob 0x289026, 0x289070

.global sUnk_8289070
sUnk_8289070:

baserom_blob 0x289070, 0x2890DA

.global sUnk_82890DA
sUnk_82890DA:

baserom_blob 0x2890DA, 0x289124

.global sUnk_8289124
sUnk_8289124:

baserom_blob 0x289124, 0x289324

.global sUnk_8289324
sUnk_8289324:

baserom_blob 0x289324, 0x28ACD8

.global sUnk_828ACD8
sUnk_828ACD8:

baserom_blob 0x28ACD8, 0x28AE1A

.global sUnk_828AE1A
sUnk_828AE1A:

baserom_blob 0x28AE1A, 0x28AE70

.global sUnk_828AE70
sUnk_828AE70:

baserom_blob 0x28AE70, 0x28AEC6

.global sUnk_828AEC6
sUnk_828AEC6:

baserom_blob 0x28AEC6, 0x28AEE8

.global sUnk_828AEE8
sUnk_828AEE8:

baserom_blob 0x28AEE8, 0x28B1C0

.global sUnk_828B1C0
sUnk_828B1C0:

baserom_blob 0x28B1C0, 0x28B210

.global sUnk_828B210
sUnk_828B210:

baserom_blob 0x28B210, 0x28B234

.global sUnk_828B234
sUnk_828B234:

baserom_blob 0x28B234, 0x28C570

.global sUnk_828C570
sUnk_828C570:

baserom_blob 0x28C570, 0x28C710

.global sUnk_828C710
sUnk_828C710:

baserom_blob 0x28C710, 0x28C730

.global sUnk_828C730
sUnk_828C730:

baserom_blob 0x28C730, 0x28E268

.global sUnk_828E268
sUnk_828E268:

baserom_blob 0x28E268, 0x28E270

.global sUnk_828E270
sUnk_828E270:

baserom_blob 0x28E270, 0x28E278

.global sUnk_828E278
sUnk_828E278:

baserom_blob 0x28E278, 0x28E304

.global sUnk_828E304
sUnk_828E304:

baserom_blob 0x28E304, 0x28E330

.global sUnk_828E330
sUnk_828E330:

baserom_blob 0x28E330, 0x28E362

.global sUnk_828E362
sUnk_828E362:

baserom_blob 0x28E362, 0x28E394

.global sUnk_828E394
sUnk_828E394:

baserom_blob 0x28E394, 0x28E3F2

.global sUnk_828E3F2
sUnk_828E3F2:

baserom_blob 0x28E3F2, 0x28E41E

.global sUnk_828E41E
sUnk_828E41E:

baserom_blob 0x28E41E, 0x28E476

.global sUnk_828E476
sUnk_828E476:

baserom_blob 0x28E476, 0x28E4A2

.global sUnk_828E4A2
sUnk_828E4A2:

baserom_blob 0x28E4A2, 0x28E4E0

.global sUnk_828E4E0
sUnk_828E4E0:

baserom_blob 0x28E4E0, 0x28E506

.global sUnk_828E506
sUnk_828E506:

baserom_blob 0x28E506, 0x28E52C

.global sUnk_828E52C
sUnk_828E52C:

baserom_blob 0x28E52C, 0x28E540

.global sUnk_828E540
sUnk_828E540:

baserom_blob 0x28E540, 0x28E566

.global sUnk_828E566
sUnk_828E566:

baserom_blob 0x28E566, 0x28E58C

.global sUnk_828E58C
sUnk_828E58C:

baserom_blob 0x28E58C, 0x28E5AC

.global sUnk_828E5AC
sUnk_828E5AC:

baserom_blob 0x28E5AC, 0x28E5CC

.global sUnk_828E5CC
sUnk_828E5CC:

baserom_blob 0x28E5CC, 0x28E5EC

.global sUnk_828E5EC
sUnk_828E5EC:

baserom_blob 0x28E5EC, 0x28E61E

.global sUnk_828E61E
sUnk_828E61E:

baserom_blob 0x28E61E, 0x28E632

.global sUnk_828E632
sUnk_828E632:

baserom_blob 0x28E632, 0x28E646

.global sUnk_828E646
sUnk_828E646:

baserom_blob 0x28E646, 0x28E660

.global sUnk_828E660
sUnk_828E660:

baserom_blob 0x28E660, 0x28E66E

.global sUnk_828E66E
sUnk_828E66E:

baserom_blob 0x28E66E, 0x28E68E

.global sUnk_828E68E
sUnk_828E68E:

baserom_blob 0x28E68E, 0x28E6BA

.global sUnk_828E6BA
sUnk_828E6BA:

baserom_blob 0x28E6BA, 0x28E6F8

.global sUnk_828E6F8
sUnk_828E6F8:

baserom_blob 0x28E6F8, 0x28E70C

.global sUnk_828E70C
sUnk_828E70C:

baserom_blob 0x28E70C, 0x28E714

.global sUnk_828E714
sUnk_828E714:

baserom_blob 0x28E714, 0x28E71C

.global sUnk_828E71C
sUnk_828E71C:

baserom_blob 0x28E71C, 0x28E74E

.global sUnk_828E74E
sUnk_828E74E:

baserom_blob 0x28E74E, 0x28E780

.global sUnk_828E780
sUnk_828E780:

baserom_blob 0x28E780, 0x28E880

.global sUnk_828E880
sUnk_828E880:

baserom_blob 0x28E880, 0x293FAC

.global sUnk_8293FAC
sUnk_8293FAC:

baserom_blob 0x293FAC, 0x293FBE

.global sUnk_8293FBE
sUnk_8293FBE:

baserom_blob 0x293FBE, 0x2940C8

.global sUnk_82940C8
sUnk_82940C8:

baserom_blob 0x2940C8, 0x2941D2

.global sUnk_82941D2
sUnk_82941D2:

baserom_blob 0x2941D2, 0x29420E

.global sUnk_829420E
sUnk_829420E:

baserom_blob 0x29420E, 0x29424A

.global sUnk_829424A
sUnk_829424A:

baserom_blob 0x29424A, 0x2942A2

.global sUnk_82942A2
sUnk_82942A2:

baserom_blob 0x2942A2, 0x2942FC

.global sUnk_82942FC
sUnk_82942FC:

baserom_blob 0x2942FC, 0x29443C

.global sUnk_829443C
sUnk_829443C:

baserom_blob 0x29443C, 0x295234

.global sUnk_8295234
sUnk_8295234:

baserom_blob 0x295234, 0x2953CA

.global sUnk_82953CA
sUnk_82953CA:

baserom_blob 0x2953CA, 0x295534

.global sUnk_8295534
sUnk_8295534:

baserom_blob 0x295534, 0x2955A6

.global sUnk_82955A6
sUnk_82955A6:

baserom_blob 0x2955A6, 0x295604

.global sUnk_8295604
sUnk_8295604:

baserom_blob 0x295604, 0x29571E

.global sUnk_829571E
sUnk_829571E:

baserom_blob 0x29571E, 0x295864

.global sUnk_8295864
sUnk_8295864:

baserom_blob 0x295864, 0x2958F2

.global sUnk_82958F2
sUnk_82958F2:

baserom_blob 0x2958F2, 0x295954

.global sUnk_8295954
sUnk_8295954:

baserom_blob 0x295954, 0x298908

.global sUnk_8298908
sUnk_8298908:

baserom_blob 0x298908, 0x29892E

.global sUnk_829892E
sUnk_829892E:

baserom_blob 0x29892E, 0x298990

.global sUnk_8298990
sUnk_8298990:

baserom_blob 0x298990, 0x298A50

.global sUnk_8298A50
sUnk_8298A50:

baserom_blob 0x298A50, 0x29A7C0

//-----

.global sUnk_829A7C0
sUnk_829A7C0:

baserom_blob 0x29A7C0, 0x29A7E6

.global sUnk_829A7E6
sUnk_829A7E6:

baserom_blob 0x29A7E6, 0x29A80C

.global sUnk_829A80C
sUnk_829A80C:

baserom_blob 0x29A80C, 0x29A850

.global sUnk_829A850
sUnk_829A850:

baserom_blob 0x29A850, 0x29A894

.global sUnk_829A894
sUnk_829A894:

baserom_blob 0x29A894, 0x29A8A8

.global sUnk_829A8A8
sUnk_829A8A8:

baserom_blob 0x29A8A8, 0x29A8BC

.global sUnk_829A8BC
sUnk_829A8BC:

baserom_blob 0x29A8BC, 0x29A8D0

.global sUnk_829A8D0
sUnk_829A8D0:

baserom_blob 0x29A8D0, 0x29A8E4

.global sUnk_829A8E4
sUnk_829A8E4:

baserom_blob 0x29A8E4, 0x29A8F8

.global sUnk_829A8F8
sUnk_829A8F8:

baserom_blob 0x29A8F8, 0x29A90C

.global sUnk_829A90C
sUnk_829A90C:

baserom_blob 0x29A90C, 0x29A926

.global sUnk_829A926
sUnk_829A926:

baserom_blob 0x29A926, 0x29A92E

.global sUnk_829A92E
sUnk_829A92E:

baserom_blob 0x29A92E, 0x29A936

.global sUnk_829A936
sUnk_829A936:

baserom_blob 0x29A936, 0x29A93E

.global sUnk_829A93E
sUnk_829A93E:

baserom_blob 0x29A93E, 0x29A952

.global sUnk_829A952
sUnk_829A952:

baserom_blob 0x29A952, 0x29A966

.global sUnk_829A966
sUnk_829A966:

baserom_blob 0x29A966, 0x29A986

.global sUnk_829A986
sUnk_829A986:

baserom_blob 0x29A986, 0x29A9A6

.global sUnk_829A9A6
sUnk_829A9A6:

baserom_blob 0x29A9A6, 0x29A9AE

.global sUnk_829A9AE
sUnk_829A9AE:

baserom_blob 0x29A9AE, 0x29A9B6

.global sUnk_829A9B6
sUnk_829A9B6:

baserom_blob 0x29A9B6, 0x29A9BE

.global sUnk_829A9BE
sUnk_829A9BE:

baserom_blob 0x29A9BE, 0x29A9D8

.global sUnk_829A9D8
sUnk_829A9D8:

baserom_blob 0x29A9D8, 0x29A9F2

.global sUnk_829A9F2
sUnk_829A9F2:

baserom_blob 0x29A9F2, 0x29AA0C

.global sUnk_829AA0C
sUnk_829AA0C:

baserom_blob 0x29AA0C, 0x29AA26

.global sUnk_829AA26
sUnk_829AA26:

baserom_blob 0x29AA26, 0x29AA3A

.global sUnk_829AA3A
sUnk_829AA3A:

baserom_blob 0x29AA3A, 0x29AA48

.global sUnk_829AA48
sUnk_829AA48:

baserom_blob 0x29AA48, 0x29AA56

.global sUnk_829AA56
sUnk_829AA56:

baserom_blob 0x29AA56, 0x29AA5E

.global sUnk_829AA5E
sUnk_829AA5E:

baserom_blob 0x29AA5E, 0x29AA6C

.global sUnk_829AA6C
sUnk_829AA6C:

baserom_blob 0x29AA6C, 0x29AA7A

.global sUnk_829AA7A
sUnk_829AA7A:

baserom_blob 0x29AA7A, 0x29AA94

.global sUnk_829AA94
sUnk_829AA94:

baserom_blob 0x29AA94, 0x29AAAE

.global sUnk_829AAAE
sUnk_829AAAE:

baserom_blob 0x29AAAE, 0x29AAE0

.global sUnk_829AAE0
sUnk_829AAE0:

baserom_blob 0x29AAE0, 0x29AB1E

.global sUnk_829AB1E
sUnk_829AB1E:

baserom_blob 0x29AB1E, 0x29AB2C

.global sUnk_829AB2C
sUnk_829AB2C:

baserom_blob 0x29AB2C, 0x29AB46

.global sUnk_829AB46
sUnk_829AB46:

baserom_blob 0x29AB46, 0x29AB84

.global sUnk_829AB84
sUnk_829AB84:

baserom_blob 0x29AB84, 0x29ABB6

.global sUnk_829ABB6
sUnk_829ABB6:

baserom_blob 0x29ABB6, 0x29AC00

.global sUnk_829AC00
sUnk_829AC00:

baserom_blob 0x29AC00, 0x29AC62

.global sUnk_829AC62
sUnk_829AC62:

baserom_blob 0x29AC62, 0x29ACC4

.global sUnk_829ACC4
sUnk_829ACC4:

baserom_blob 0x29ACC4, 0x29AD0E

.global sUnk_829AD0E
sUnk_829AD0E:

baserom_blob 0x29AD0E, 0x29AD58

.global sUnk_829AD58
sUnk_829AD58:

baserom_blob 0x29AD58, 0x29AD8A

.global sUnk_829AD8A
sUnk_829AD8A:

baserom_blob 0x29AD8A, 0x29ADA4

.global sUnk_829ADA4
sUnk_829ADA4:

baserom_blob 0x29ADA4, 0x29ADBE

.global sUnk_829ADBE
sUnk_829ADBE:

baserom_blob 0x29ADBE, 0x29ADEA

.global sUnk_829ADEA
sUnk_829ADEA:

baserom_blob 0x29ADEA, 0x29ADF8

.global sUnk_829ADF8
sUnk_829ADF8:

baserom_blob 0x29ADF8, 0x29AE06

.global sUnk_829AE06
sUnk_829AE06:

baserom_blob 0x29AE06, 0x29AE14

.global sUnk_829AE14
sUnk_829AE14:

baserom_blob 0x29AE14, 0x29AE22

.global sUnk_829AE22
sUnk_829AE22:

baserom_blob 0x29AE22, 0x29AE30

.global sUnk_829AE30
sUnk_829AE30:

baserom_blob 0x29AE30, 0x29AE3E

.global sUnk_829AE3E
sUnk_829AE3E:

baserom_blob 0x29AE3E, 0x29B03E

.global sUnk_829B03E
sUnk_829B03E:

baserom_blob 0x29B03E, 0x29B240

.global sUnk_829B240
sUnk_829B240:

baserom_blob 0x29B240, 0x29B2C0

.global sUnk_829B2C0
sUnk_829B2C0:

baserom_blob 0x29B2C0, 0x29D194

.global sUnk_829D194
sUnk_829D194:

baserom_blob 0x29D194, 0x29D1D4

.global sUnk_829D1D4
sUnk_829D1D4:

baserom_blob 0x29D1D4, 0x29D212

.global sUnk_829D212
sUnk_829D212:

baserom_blob 0x29D212, 0x29D270

.global sUnk_829D270
sUnk_829D270:

baserom_blob 0x29D270, 0x29D46E

.global sUnk_829D46E
sUnk_829D46E:

baserom_blob 0x29D46E, 0x29D4D0

.global sUnk_829D4D0
sUnk_829D4D0:

baserom_blob 0x29D4D0, 0x29F4D4

//-----

.global sUnk_829F4D4
sUnk_829F4D4:

baserom_blob 0x29F4D4, 0x29F4DC

.global sUnk_829F4DC
sUnk_829F4DC:

baserom_blob 0x29F4DC, 0x29F520

.global sUnk_829F520
sUnk_829F520:

baserom_blob 0x29F520, 0x29F558

.global sUnk_829F558
sUnk_829F558:

baserom_blob 0x29F558, 0x29F590

.global sUnk_829F590
sUnk_829F590:

baserom_blob 0x29F590, 0x29F5D4

.global sUnk_829F5D4
sUnk_829F5D4:

baserom_blob 0x29F5D4, 0x29F63C

.global sUnk_829F63C
sUnk_829F63C:

baserom_blob 0x29F63C, 0x29F686

.global sUnk_829F686
sUnk_829F686:

baserom_blob 0x29F686, 0x29F6B8

.global sUnk_829F6B8
sUnk_829F6B8:

baserom_blob 0x29F6B8, 0x29F6E4

.global sUnk_829F6E4
sUnk_829F6E4:

baserom_blob 0x29F6E4, 0x29F710

.global sUnk_829F710
sUnk_829F710:

baserom_blob 0x29F710, 0x29F718

.global sUnk_829F718
sUnk_829F718:

baserom_blob 0x29F718, 0x29F720

.global sUnk_829F720
sUnk_829F720:

baserom_blob 0x29F720, 0x29F728

.global sUnk_829F728
sUnk_829F728:

baserom_blob 0x29F728, 0x29F730

.global sUnk_829F730
sUnk_829F730:

baserom_blob 0x29F730, 0x29F738

.global sUnk_829F738
sUnk_829F738:

baserom_blob 0x29F738, 0x29F764

.global sUnk_829F764
sUnk_829F764:

baserom_blob 0x29F764, 0x29F790

.global sUnk_829F790
sUnk_829F790:

baserom_blob 0x29F790, 0x29F7E6

.global sUnk_829F7E6
sUnk_829F7E6:

baserom_blob 0x29F7E6, 0x29F85A

.global sUnk_829F85A
sUnk_829F85A:

baserom_blob 0x29F85A, 0x29F8AA

.global sUnk_829F8AA
sUnk_829F8AA:

baserom_blob 0x29F8AA, 0x29F8FA

.global sUnk_829F8FA
sUnk_829F8FA:

baserom_blob 0x29F8FA, 0x29F93E

.global sUnk_829F93E
sUnk_829F93E:

baserom_blob 0x29F93E, 0x29F946

.global sUnk_829F946
sUnk_829F946:

baserom_blob 0x29F946, 0x29F94E

.global sUnk_829F94E
sUnk_829F94E:

baserom_blob 0x29F94E, 0x29F956

.global sUnk_829F956
sUnk_829F956:

baserom_blob 0x29F956, 0x29F95E

.global sUnk_829F95E
sUnk_829F95E:

baserom_blob 0x29F95E, 0x29F9B4

.global sUnk_829F9B4
sUnk_829F9B4:

baserom_blob 0x29F9B4, 0x29FA0A

.global sUnk_829FA0A
sUnk_829FA0A:

baserom_blob 0x29FA0A, 0x29FA48

.global sUnk_829FA48
sUnk_829FA48:

baserom_blob 0x29FA48, 0x29FA86

.global sUnk_829FA86
sUnk_829FA86:

baserom_blob 0x29FA86, 0x29FB76

.global sUnk_829FB76
sUnk_829FB76:

baserom_blob 0x29FB76, 0x29FC66

.global sUnk_829FC66
sUnk_829FC66:

baserom_blob 0x29FC66, 0x29FD48

.global sUnk_829FD48
sUnk_829FD48:

baserom_blob 0x29FD48, 0x29FF48

.global sUnk_829FF48
sUnk_829FF48:

baserom_blob 0x29FF48, 0x2A1CF0

.global sUnk_82A1CF0
sUnk_82A1CF0:

baserom_blob 0x2A1CF0, 0x2A1E7A

.global sUnk_82A1E7A
sUnk_82A1E7A:

baserom_blob 0x2A1E7A, 0x2A1FBC

.global sUnk_82A1FBC
sUnk_82A1FBC:

baserom_blob 0x2A1FBC, 0x2A229C

.global sUnk_82A229C
sUnk_82A229C:

baserom_blob 0x2A229C, 0x2A2840

.global sUnk_82A2840
sUnk_82A2840:

baserom_blob 0x2A2840, 0x2A2A24

.global sUnk_82A2A24
sUnk_82A2A24:

baserom_blob 0x2A2A24, 0x2A2CD0

.global sUnk_82A2CD0
sUnk_82A2CD0:

baserom_blob 0x2A2CD0, 0x2A2F12

.global sUnk_82A2F12
sUnk_82A2F12:

baserom_blob 0x2A2F12, 0x2A2F74

.global sUnk_82A2F74
sUnk_82A2F74:

baserom_blob 0x2A2F74, 0x2A34A4

//-----

.global sCutsceneWarioEffectAFrame0Oam
sCutsceneWarioEffectAFrame0Oam:

baserom_blob 0x2A34A4, 0x2A34B2

.global sCutsceneWarioEffectAFrame1Oam
sCutsceneWarioEffectAFrame1Oam:

baserom_blob 0x2A34B2, 0x2A34C0

.global sCutsceneWarioEffectAFrame2Oam
sCutsceneWarioEffectAFrame2Oam:

baserom_blob 0x2A34C0, 0x2A34CE

.global sCutsceneWarioEffectAFrame3Oam
sCutsceneWarioEffectAFrame3Oam:

baserom_blob 0x2A34CE, 0x2A34DC

.global sCutsceneWarioEffectAFrame4Oam
sCutsceneWarioEffectAFrame4Oam:

baserom_blob 0x2A34DC, 0x2A34F6

.global sCutsceneWarioEffectAFrame5Oam
sCutsceneWarioEffectAFrame5Oam:

baserom_blob 0x2A34F6, 0x2A3510

.global sCutsceneWarioEffectAFrame6Oam
sCutsceneWarioEffectAFrame6Oam:

baserom_blob 0x2A3510, 0x2A352A

.global sCutsceneWarioEffectAFrame7Oam
sCutsceneWarioEffectAFrame7Oam:

baserom_blob 0x2A352A, 0x2A3544

.global sCutsceneWarioEffectAFrame8Oam
sCutsceneWarioEffectAFrame8Oam:

baserom_blob 0x2A3544, 0x2A355E

.global sCutsceneWarioEffectAFrame9Oam
sCutsceneWarioEffectAFrame9Oam:

baserom_blob 0x2A355E, 0x2A3578

.global sCutsceneWarioEffectAFrame10Oam
sCutsceneWarioEffectAFrame10Oam:

baserom_blob 0x2A3578, 0x2A3592

.global sCutsceneWarioEffectAFrame11Oam
sCutsceneWarioEffectAFrame11Oam:

baserom_blob 0x2A3592, 0x2A35AC

.global sCutsceneWarioEffectBFrame0Oam
sCutsceneWarioEffectBFrame0Oam:

baserom_blob 0x2A35AC, 0x2A35C6

.global sCutsceneWarioEffectBFrame1Oam
sCutsceneWarioEffectBFrame1Oam:

baserom_blob 0x2A35C6, 0x2A35E0

.global sCutsceneWarioEffectBFrame2Oam
sCutsceneWarioEffectBFrame2Oam:

baserom_blob 0x2A35E0, 0x2A35FA

.global sCutsceneWarioEffectBFrame3Oam
sCutsceneWarioEffectBFrame3Oam:

baserom_blob 0x2A35FA, 0x2A3614

.global sCutsceneWarioEffectCFrame0Oam
sCutsceneWarioEffectCFrame0Oam:

baserom_blob 0x2A3614, 0x2A3622

.global sCutsceneWarioEffectCFrame1Oam
sCutsceneWarioEffectCFrame1Oam:

baserom_blob 0x2A3622, 0x2A3636

.global sCutsceneWarioEffectCFrame2Oam
sCutsceneWarioEffectCFrame2Oam:

baserom_blob 0x2A3636, 0x2A3650

.global sCutsceneWarioEffectCFrame3Oam
sCutsceneWarioEffectCFrame3Oam:

baserom_blob 0x2A3650, 0x2A366A

.global sCutsceneWarioEffectCFrame4Oam
sCutsceneWarioEffectCFrame4Oam:

baserom_blob 0x2A366A, 0x2A3684

.global sCutsceneWarioEffectDFrame0Oam
sCutsceneWarioEffectDFrame0Oam:

baserom_blob 0x2A3684, 0x2A368C

.global sCutsceneWarioEffectDFrame1Oam
sCutsceneWarioEffectDFrame1Oam:

baserom_blob 0x2A368C, 0x2A3694

.global sCutsceneWarioEffectDFrame2Oam
sCutsceneWarioEffectDFrame2Oam:

baserom_blob 0x2A3694, 0x2A369C

.global sCutsceneWarioEffectDFrame3Oam
sCutsceneWarioEffectDFrame3Oam:

baserom_blob 0x2A369C, 0x2A36A4

.global sCutsceneWarioEffectDFrame4Oam
sCutsceneWarioEffectDFrame4Oam:

baserom_blob 0x2A36A4, 0x2A36AC

.global sUnk_82A36AC
sUnk_82A36AC:

baserom_blob 0x2A36AC, 0x2A36CC

.global sUnk_82A36CC
sUnk_82A36CC:

baserom_blob 0x2A36CC, 0x2A3710

.global sUnk_82A3710
sUnk_82A3710:

baserom_blob 0x2A3710, 0x2A3760

.global sCutsceneWarioEffectEFrame0Oam
sCutsceneWarioEffectEFrame0Oam:

baserom_blob 0x2A3760, 0x2A3768

.global sCutsceneWarioEffectEFrame1Oam
sCutsceneWarioEffectEFrame1Oam:

baserom_blob 0x2A3768, 0x2A3770

.global sCutsceneWarioEffectEFrame2Oam
sCutsceneWarioEffectEFrame2Oam:

baserom_blob 0x2A3770, 0x2A3778

.global sCutsceneWarioEffectEFrame3Oam
sCutsceneWarioEffectEFrame3Oam:

baserom_blob 0x2A3778, 0x2A3780

.global sCutsceneWarioEffectFFrame0Oam
sCutsceneWarioEffectFFrame0Oam:

baserom_blob 0x2A3780, 0x2A3788

.global sCutsceneWarioEffectFFrame1Oam
sCutsceneWarioEffectFFrame1Oam:

baserom_blob 0x2A3788, 0x2A3790

.global sCutsceneWarioEffectFFrame2Oam
sCutsceneWarioEffectFFrame2Oam:

baserom_blob 0x2A3790, 0x2A3798

.global sCutsceneWarioEffectFFrame3Oam
sCutsceneWarioEffectFFrame3Oam:

baserom_blob 0x2A3798, 0x2A37A0

.global sUnk_82A37A0
sUnk_82A37A0:

baserom_blob 0x2A37A0, 0x2A37C0

.global sUnk_82A37C0
sUnk_82A37C0:

baserom_blob 0x2A37C0, 0x2A47A0

.global sUnk_82A47A0
sUnk_82A47A0:

baserom_blob 0x2A47A0, 0x2A47C0

.global sUnk_82A47C0
sUnk_82A47C0:

baserom_blob 0x2A47C0, 0x2A4934

.global sUnk_82A4934
sUnk_82A4934:

baserom_blob 0x2A4934, 0x2A4E1A

.global sUnk_82A4E1A
sUnk_82A4E1A:

baserom_blob 0x2A4E1A, 0x2A4E3C

.global sUnk_82A4E3C
sUnk_82A4E3C:

baserom_blob 0x2A4E3C, 0x2A5310

.global sCutsceneWarioStaticOam
sCutsceneWarioStaticOam:

baserom_blob 0x2A5310, 0x2A5318

.global sUnk_82A5318
sUnk_82A5318:

baserom_blob 0x2A5318, 0x2A53F8

.global sUnk_82A53F8
sUnk_82A53F8:

baserom_blob 0x2A53F8, 0x2A7590

//-----

.global sLayeredCutsceneOamFrame000
sLayeredCutsceneOamFrame000:

baserom_blob 0x2A7590, 0x2A75C8

.global sLayeredCutsceneOamFrame001
sLayeredCutsceneOamFrame001:

baserom_blob 0x2A75C8, 0x2A75FA

.global sLayeredCutsceneOamFrame002
sLayeredCutsceneOamFrame002:

baserom_blob 0x2A75FA, 0x2A7632

.global sLayeredCutsceneOamFrame003
sLayeredCutsceneOamFrame003:

baserom_blob 0x2A7632, 0x2A766A

.global sLayeredCutsceneOamFrame004
sLayeredCutsceneOamFrame004:

baserom_blob 0x2A766A, 0x2A76A2

.global sLayeredCutsceneOamFrame005
sLayeredCutsceneOamFrame005:

baserom_blob 0x2A76A2, 0x2A76D4

.global sLayeredCutsceneOamFrame006
sLayeredCutsceneOamFrame006:

baserom_blob 0x2A76D4, 0x2A770C

.global sLayeredCutsceneOamFrame007
sLayeredCutsceneOamFrame007:

baserom_blob 0x2A770C, 0x2A7744

.global sLayeredCutsceneOamFrame008
sLayeredCutsceneOamFrame008:

baserom_blob 0x2A7744, 0x2A7752

.global sLayeredCutsceneOamFrame009
sLayeredCutsceneOamFrame009:

baserom_blob 0x2A7752, 0x2A7760

.global sLayeredCutsceneOamFrame010
sLayeredCutsceneOamFrame010:

baserom_blob 0x2A7760, 0x2A776E

.global sLayeredCutsceneOamFrame011
sLayeredCutsceneOamFrame011:

baserom_blob 0x2A776E, 0x2A777C

.global sLayeredCutsceneOamFrame012
sLayeredCutsceneOamFrame012:

baserom_blob 0x2A777C, 0x2A778A

.global sLayeredCutsceneOamFrame013
sLayeredCutsceneOamFrame013:

baserom_blob 0x2A778A, 0x2A7798

.global sLayeredCutsceneOamFrame014
sLayeredCutsceneOamFrame014:

baserom_blob 0x2A7798, 0x2A77D0

.global sLayeredCutsceneOamFrame015
sLayeredCutsceneOamFrame015:

baserom_blob 0x2A77D0, 0x2A7802

.global sLayeredCutsceneOamFrame016
sLayeredCutsceneOamFrame016:

baserom_blob 0x2A7802, 0x2A7834

.global sLayeredCutsceneOamFrame017
sLayeredCutsceneOamFrame017:

baserom_blob 0x2A7834, 0x2A783C

.global sLayeredCutsceneOamFrame018
sLayeredCutsceneOamFrame018:

baserom_blob 0x2A783C, 0x2A7874

.global sLayeredCutsceneOamFrame019
sLayeredCutsceneOamFrame019:

baserom_blob 0x2A7874, 0x2A78AC

.global sLayeredCutsceneOamFrame020
sLayeredCutsceneOamFrame020:

baserom_blob 0x2A78AC, 0x2A78E4

.global sLayeredCutsceneOamFrame021
sLayeredCutsceneOamFrame021:

baserom_blob 0x2A78E4, 0x2A78EC

.global sLayeredCutsceneOamFrame022
sLayeredCutsceneOamFrame022:

baserom_blob 0x2A78EC, 0x2A78F4

.global sLayeredCutsceneOamFrame023
sLayeredCutsceneOamFrame023:

baserom_blob 0x2A78F4, 0x2A78FC

.global sLayeredCutsceneOamFrame024
sLayeredCutsceneOamFrame024:

baserom_blob 0x2A78FC, 0x2A7904

.global sLayeredCutsceneOamFrame025
sLayeredCutsceneOamFrame025:

baserom_blob 0x2A7904, 0x2A790C

.global sLayeredCutsceneOamFrame026
sLayeredCutsceneOamFrame026:

baserom_blob 0x2A790C, 0x2A7914

.global sLayeredCutsceneOamFrame027
sLayeredCutsceneOamFrame027:

baserom_blob 0x2A7914, 0x2A791C

.global sLayeredCutsceneOamFrame028
sLayeredCutsceneOamFrame028:

baserom_blob 0x2A791C, 0x2A7924

.global sLayeredCutsceneOamFrame029
sLayeredCutsceneOamFrame029:

baserom_blob 0x2A7924, 0x2A792C

.global sLayeredCutsceneOamFrame030
sLayeredCutsceneOamFrame030:

baserom_blob 0x2A792C, 0x2A7934

.global sLayeredCutsceneOamFrame031
sLayeredCutsceneOamFrame031:

baserom_blob 0x2A7934, 0x2A793C

.global sLayeredCutsceneOamFrame032
sLayeredCutsceneOamFrame032:

baserom_blob 0x2A793C, 0x2A7944

.global sLayeredCutsceneOamFrame033
sLayeredCutsceneOamFrame033:

baserom_blob 0x2A7944, 0x2A794C

.global sLayeredCutsceneOamFrame034
sLayeredCutsceneOamFrame034:

baserom_blob 0x2A794C, 0x2A7954

.global sLayeredCutsceneOamFrame035
sLayeredCutsceneOamFrame035:

baserom_blob 0x2A7954, 0x2A795C

.global sLayeredCutsceneOamFrame036
sLayeredCutsceneOamFrame036:

baserom_blob 0x2A795C, 0x2A7964

.global sLayeredCutsceneOamFrame037
sLayeredCutsceneOamFrame037:

baserom_blob 0x2A7964, 0x2A796C

.global sLayeredCutsceneOamFrame038
sLayeredCutsceneOamFrame038:

baserom_blob 0x2A796C, 0x2A7974

.global sLayeredCutsceneOamFrame039
sLayeredCutsceneOamFrame039:

baserom_blob 0x2A7974, 0x2A79A6

.global sLayeredCutsceneOamFrame040
sLayeredCutsceneOamFrame040:

baserom_blob 0x2A79A6, 0x2A79D2

.global sLayeredCutsceneOamFrame041
sLayeredCutsceneOamFrame041:

baserom_blob 0x2A79D2, 0x2A7A04

.global sLayeredCutsceneOamFrame042
sLayeredCutsceneOamFrame042:

baserom_blob 0x2A7A04, 0x2A7A36

.global sLayeredCutsceneOamFrame043
sLayeredCutsceneOamFrame043:

baserom_blob 0x2A7A36, 0x2A7A68

.global sLayeredCutsceneOamFrame044
sLayeredCutsceneOamFrame044:

baserom_blob 0x2A7A68, 0x2A7A94

.global sLayeredCutsceneOamFrame045
sLayeredCutsceneOamFrame045:

baserom_blob 0x2A7A94, 0x2A7AC6

.global sLayeredCutsceneOamFrame046
sLayeredCutsceneOamFrame046:

baserom_blob 0x2A7AC6, 0x2A7AF8

.global sLayeredCutsceneOamFrame047
sLayeredCutsceneOamFrame047:

baserom_blob 0x2A7AF8, 0x2A7B2A

.global sLayeredCutsceneOamFrame048
sLayeredCutsceneOamFrame048:

baserom_blob 0x2A7B2A, 0x2A7B56

.global sLayeredCutsceneOamFrame049
sLayeredCutsceneOamFrame049:

baserom_blob 0x2A7B56, 0x2A7B82

.global sLayeredCutsceneOamFrame050
sLayeredCutsceneOamFrame050:

baserom_blob 0x2A7B82, 0x2A7BBA

.global sLayeredCutsceneOamFrame051
sLayeredCutsceneOamFrame051:

baserom_blob 0x2A7BBA, 0x2A7BF2

.global sLayeredCutsceneOamFrame052
sLayeredCutsceneOamFrame052:

baserom_blob 0x2A7BF2, 0x2A7C2A

.global sLayeredCutsceneOamFrame053
sLayeredCutsceneOamFrame053:

baserom_blob 0x2A7C2A, 0x2A7C44

.global sLayeredCutsceneOamFrame054
sLayeredCutsceneOamFrame054:

baserom_blob 0x2A7C44, 0x2A7C64

.global sLayeredCutsceneOamFrame055
sLayeredCutsceneOamFrame055:

baserom_blob 0x2A7C64, 0x2A7C78

.global sLayeredCutsceneOamFrame056
sLayeredCutsceneOamFrame056:

baserom_blob 0x2A7C78, 0x2A7C98

.global sLayeredCutsceneOamFrame057
sLayeredCutsceneOamFrame057:

baserom_blob 0x2A7C98, 0x2A7CBE

.global sLayeredCutsceneOamFrame058
sLayeredCutsceneOamFrame058:

baserom_blob 0x2A7CBE, 0x2A7CCC

.global sLayeredCutsceneOamFrame059
sLayeredCutsceneOamFrame059:

baserom_blob 0x2A7CCC, 0x2A7CDA

.global sLayeredCutsceneOamFrame060
sLayeredCutsceneOamFrame060:

baserom_blob 0x2A7CDA, 0x2A7D18

.global sLayeredCutsceneOamFrame061
sLayeredCutsceneOamFrame061:

baserom_blob 0x2A7D18, 0x2A7D56

.global sLayeredCutsceneOamFrame062
sLayeredCutsceneOamFrame062:

baserom_blob 0x2A7D56, 0x2A7D94

.global sLayeredCutsceneOamFrame063
sLayeredCutsceneOamFrame063:

baserom_blob 0x2A7D94, 0x2A7DCC

.global sLayeredCutsceneOamFrame064
sLayeredCutsceneOamFrame064:

baserom_blob 0x2A7DCC, 0x2A7E0A

.global sLayeredCutsceneOamFrame065
sLayeredCutsceneOamFrame065:

baserom_blob 0x2A7E0A, 0x2A7E48

.global sLayeredCutsceneOamFrame066
sLayeredCutsceneOamFrame066:

baserom_blob 0x2A7E48, 0x2A7E86

.global sLayeredCutsceneOamFrame067
sLayeredCutsceneOamFrame067:

baserom_blob 0x2A7E86, 0x2A7EC4

.global sLayeredCutsceneOamFrame068
sLayeredCutsceneOamFrame068:

baserom_blob 0x2A7EC4, 0x2A7F02

.global sLayeredCutsceneOamFrame069
sLayeredCutsceneOamFrame069:

baserom_blob 0x2A7F02, 0x2A7F40

.global sLayeredCutsceneOamFrame070
sLayeredCutsceneOamFrame070:

baserom_blob 0x2A7F40, 0x2A7F7E

.global sLayeredCutsceneOamFrame071
sLayeredCutsceneOamFrame071:

baserom_blob 0x2A7F7E, 0x2A7FB6

.global sLayeredCutsceneOamFrame072
sLayeredCutsceneOamFrame072:

baserom_blob 0x2A7FB6, 0x2A7FF4

.global sLayeredCutsceneOamFrame073
sLayeredCutsceneOamFrame073:

baserom_blob 0x2A7FF4, 0x2A8032

.global sLayeredCutsceneOamFrame074
sLayeredCutsceneOamFrame074:

baserom_blob 0x2A8032, 0x2A8070

.global sLayeredCutsceneOamFrame075
sLayeredCutsceneOamFrame075:

baserom_blob 0x2A8070, 0x2A80AE

.global sLayeredCutsceneOamFrame076
sLayeredCutsceneOamFrame076:

baserom_blob 0x2A80AE, 0x2A80B6

.global sLayeredCutsceneOamFrame077
sLayeredCutsceneOamFrame077:

baserom_blob 0x2A80B6, 0x2A80BE

.global sLayeredCutsceneOamFrame078
sLayeredCutsceneOamFrame078:

baserom_blob 0x2A80BE, 0x2A80C6

.global sLayeredCutsceneOamFrame079
sLayeredCutsceneOamFrame079:

baserom_blob 0x2A80C6, 0x2A80CE

.global sLayeredCutsceneOamFrame080
sLayeredCutsceneOamFrame080:

baserom_blob 0x2A80CE, 0x2A80D6

.global sLayeredCutsceneOamFrame081
sLayeredCutsceneOamFrame081:

baserom_blob 0x2A80D6, 0x2A80DE

.global sLayeredCutsceneOamFrame082
sLayeredCutsceneOamFrame082:

baserom_blob 0x2A80DE, 0x2A80E6

.global sLayeredCutsceneOamFrame083
sLayeredCutsceneOamFrame083:

baserom_blob 0x2A80E6, 0x2A80EE

.global sLayeredCutsceneOamFrame084
sLayeredCutsceneOamFrame084:

baserom_blob 0x2A80EE, 0x2A80F6

.global sLayeredCutsceneOamFrame085
sLayeredCutsceneOamFrame085:

baserom_blob 0x2A80F6, 0x2A80FE

.global sLayeredCutsceneOamFrame086
sLayeredCutsceneOamFrame086:

baserom_blob 0x2A80FE, 0x2A8106

.global sLayeredCutsceneOamFrame087
sLayeredCutsceneOamFrame087:

baserom_blob 0x2A8106, 0x2A810E

.global sLayeredCutsceneOamFrame088
sLayeredCutsceneOamFrame088:

baserom_blob 0x2A810E, 0x2A8116

.global sLayeredCutsceneOamFrame089
sLayeredCutsceneOamFrame089:

baserom_blob 0x2A8116, 0x2A8126

.global sLayeredCutsceneOamFrame090
sLayeredCutsceneOamFrame090:

baserom_blob 0x2A8126, 0x2A812E

.global sLayeredCutsceneOamFrame091
sLayeredCutsceneOamFrame091:

baserom_blob 0x2A812E, 0x2A8136

.global sLayeredCutsceneOamFrame092
sLayeredCutsceneOamFrame092:

baserom_blob 0x2A8136, 0x2A813E

.global sLayeredCutsceneOamFrame093
sLayeredCutsceneOamFrame093:

baserom_blob 0x2A813E, 0x2A8146

.global sLayeredCutsceneOamFrame094
sLayeredCutsceneOamFrame094:

baserom_blob 0x2A8146, 0x2A814E

//-----

.global sCutsceneGfx1_Frame0
sCutsceneGfx1_Frame0:

baserom_blob 0x2A814E, 0x2A8168

.global sCutsceneGfx1_Frame1
sCutsceneGfx1_Frame1:

baserom_blob 0x2A8168, 0x2A8182

.global sCutsceneGfx1_Frame2
sCutsceneGfx1_Frame2:

baserom_blob 0x2A8182, 0x2A819C

.global sCutsceneGfx1_Frame3
sCutsceneGfx1_Frame3:

baserom_blob 0x2A819C, 0x2A81B6

.global sCutsceneGfx2_Frame0
sCutsceneGfx2_Frame0:

baserom_blob 0x2A81B6, 0x2A81D6

.global sCutsceneGfx2_Frame1
sCutsceneGfx2_Frame1:

baserom_blob 0x2A81D6, 0x2A821A

.global sCutsceneGfx2_Frame2
sCutsceneGfx2_Frame2:

baserom_blob 0x2A821A, 0x2A828E

.global sCutsceneGfx2_Frame3
sCutsceneGfx2_Frame3:

baserom_blob 0x2A828E, 0x2A831A

.global sCutsceneGfx2_Frame4
sCutsceneGfx2_Frame4:

baserom_blob 0x2A831A, 0x2A8394

.global sCutsceneGfx2_Frame5
sCutsceneGfx2_Frame5:

baserom_blob 0x2A8394, 0x2A83F6

.global sCutsceneGfx2_Frame6
sCutsceneGfx2_Frame6:

baserom_blob 0x2A83F6, 0x2A8410

.global sCutsceneGfx3_Frame0
sCutsceneGfx3_Frame0:

baserom_blob 0x2A8410, 0x2A8418

.global sCutsceneGfx3_Frame1
sCutsceneGfx3_Frame1:

baserom_blob 0x2A8418, 0x2A8420

.global sCutsceneGfx3_Frame2
sCutsceneGfx3_Frame2:

baserom_blob 0x2A8420, 0x2A8428

.global sCutsceneGfx3_Frame3
sCutsceneGfx3_Frame3:

baserom_blob 0x2A8428, 0x2A8436

.global sCutsceneGfx4_Frame0
sCutsceneGfx4_Frame0:

baserom_blob 0x2A8436, 0x2A8450

.global sCutsceneGfx4_Frame1
sCutsceneGfx4_Frame1:

baserom_blob 0x2A8450, 0x2A849A

.global sCutsceneGfx4_Frame2
sCutsceneGfx4_Frame2:

baserom_blob 0x2A849A, 0x2A84FC

.global sCutsceneGfx4_Frame3
sCutsceneGfx4_Frame3:

baserom_blob 0x2A84FC, 0x2A855E

.global sCutsceneGfx4_Frame4
sCutsceneGfx4_Frame4:

baserom_blob 0x2A855E, 0x2A85AE

.global sCutsceneGfx4_Frame5
sCutsceneGfx4_Frame5:

baserom_blob 0x2A85AE, 0x2A85CE

.global sCutsceneGfx4_Frame6
sCutsceneGfx4_Frame6:

baserom_blob 0x2A85CE, 0x2A85D6

.global sCutsceneGfx4_Frame7
sCutsceneGfx4_Frame7:

baserom_blob 0x2A85D6, 0x2A85E4

.global sCutsceneGfx5_Frame0
sCutsceneGfx5_Frame0:

baserom_blob 0x2A85E4, 0x2A8660

.global sCutsceneGfx5_Frame1
sCutsceneGfx5_Frame1:

baserom_blob 0x2A8660, 0x2A86C2

.global sCutsceneGfx5_Frame2
sCutsceneGfx5_Frame2:

baserom_blob 0x2A86C2, 0x2A8724

.global sCutsceneGfx5_Frame3
sCutsceneGfx5_Frame3:

baserom_blob 0x2A8724, 0x2A876E

.global sCutsceneGfx5_Frame4
sCutsceneGfx5_Frame4:

baserom_blob 0x2A876E, 0x2A87B8

.global sCutsceneGfx5_Frame5
sCutsceneGfx5_Frame5:

baserom_blob 0x2A87B8, 0x2A87EA

.global sCutsceneGfx5_Frame6
sCutsceneGfx5_Frame6:

baserom_blob 0x2A87EA, 0x2A8804

.global sCutsceneGfx5_Frame7
sCutsceneGfx5_Frame7:

baserom_blob 0x2A8804, 0x2A8820

.global sUnk_82A8820
sUnk_82A8820:

baserom_blob 0x2A8820, 0x2A88E0

.global sUnk_82A88E0
sUnk_82A88E0:

baserom_blob 0x2A88E0, 0x2A9508

.global sUnk_82A9508
sUnk_82A9508:

baserom_blob 0x2A9508, 0x2AA07C

.global sUnk_82AA07C
sUnk_82AA07C:

baserom_blob 0x2AA07C, 0x2AA202

.global sUnk_82AA202
sUnk_82AA202:

baserom_blob 0x2AA202, 0x2AA2B0

.global sUnk_82AA2B0
sUnk_82AA2B0:

baserom_blob 0x2AA2B0, 0x2AA5B2

.global sUnk_82AA5B2
sUnk_82AA5B2:

baserom_blob 0x2AA5B2, 0x2AA7B4

.global sUnk_82AA7B4
sUnk_82AA7B4:

baserom_blob 0x2AA7B4, 0x2AE088

//-----

.global sEndingCutsceneOamFrame000
sEndingCutsceneOamFrame000:

baserom_blob 0x2AE088, 0x2AE0CC

.global sEndingCutsceneOamFrame001
sEndingCutsceneOamFrame001:

baserom_blob 0x2AE0CC, 0x2AE10A

.global sEndingCutsceneOamFrame002
sEndingCutsceneOamFrame002:

baserom_blob 0x2AE10A, 0x2AE148

.global sEndingCutsceneOamFrame003
sEndingCutsceneOamFrame003:

baserom_blob 0x2AE148, 0x2AE18C

.global sEndingCutsceneOamFrame004
sEndingCutsceneOamFrame004:

baserom_blob 0x2AE18C, 0x2AE1D0

.global sEndingCutsceneOamFrame005
sEndingCutsceneOamFrame005:

baserom_blob 0x2AE1D0, 0x2AE214

.global sEndingCutsceneOamFrame006
sEndingCutsceneOamFrame006:

baserom_blob 0x2AE214, 0x2AE258

.global sEndingCutsceneOamFrame007
sEndingCutsceneOamFrame007:

baserom_blob 0x2AE258, 0x2AE29C

.global sEndingCutsceneOamFrame008
sEndingCutsceneOamFrame008:

baserom_blob 0x2AE29C, 0x2AE2E0

.global sEndingCutsceneOamFrame009
sEndingCutsceneOamFrame009:

baserom_blob 0x2AE2E0, 0x2AE324

.global sEndingCutsceneOamFrame010
sEndingCutsceneOamFrame010:

baserom_blob 0x2AE324, 0x2AE362

.global sEndingCutsceneOamFrame011
sEndingCutsceneOamFrame011:

baserom_blob 0x2AE362, 0x2AE370

.global sEndingCutsceneOamFrame012
sEndingCutsceneOamFrame012:

baserom_blob 0x2AE370, 0x2AE384

.global sEndingCutsceneOamFrame013
sEndingCutsceneOamFrame013:

baserom_blob 0x2AE384, 0x2AE392

.global sEndingCutsceneOamFrame014
sEndingCutsceneOamFrame014:

baserom_blob 0x2AE392, 0x2AE3A0

.global sEndingCutsceneOamFrame015
sEndingCutsceneOamFrame015:

baserom_blob 0x2AE3A0, 0x2AE3AE

.global sEndingCutsceneOamFrame016
sEndingCutsceneOamFrame016:

baserom_blob 0x2AE3AE, 0x2AE3CE

.global sEndingCutsceneOamFrame017
sEndingCutsceneOamFrame017:

baserom_blob 0x2AE3CE, 0x2AE3F4

.global sEndingCutsceneOamFrame018
sEndingCutsceneOamFrame018:

baserom_blob 0x2AE3F4, 0x2AE41A

.global sEndingCutsceneOamFrame019
sEndingCutsceneOamFrame019:

baserom_blob 0x2AE41A, 0x2AE44C

.global sEndingCutsceneOamFrame020
sEndingCutsceneOamFrame020:

baserom_blob 0x2AE44C, 0x2AE47E

.global sEndingCutsceneOamFrame021
sEndingCutsceneOamFrame021:

baserom_blob 0x2AE47E, 0x2AE4B0

.global sEndingCutsceneOamFrame022
sEndingCutsceneOamFrame022:

baserom_blob 0x2AE4B0, 0x2AE4E2

.global sEndingCutsceneOamFrame023
sEndingCutsceneOamFrame023:

baserom_blob 0x2AE4E2, 0x2AE514

.global sEndingCutsceneOamFrame024
sEndingCutsceneOamFrame024:

baserom_blob 0x2AE514, 0x2AE534

.global sEndingCutsceneOamFrame025
sEndingCutsceneOamFrame025:

baserom_blob 0x2AE534, 0x2AE566

.global sEndingCutsceneOamFrame026
sEndingCutsceneOamFrame026:

baserom_blob 0x2AE566, 0x2AE592

.global sEndingCutsceneOamFrame027
sEndingCutsceneOamFrame027:

baserom_blob 0x2AE592, 0x2AE5CA

.global sEndingCutsceneOamFrame028
sEndingCutsceneOamFrame028:

baserom_blob 0x2AE5CA, 0x2AE602

.global sEndingCutsceneOamFrame029
sEndingCutsceneOamFrame029:

baserom_blob 0x2AE602, 0x2AE63A

.global sEndingCutsceneOamFrame030
sEndingCutsceneOamFrame030:

baserom_blob 0x2AE63A, 0x2AE672

.global sEndingCutsceneOamFrame031
sEndingCutsceneOamFrame031:

baserom_blob 0x2AE672, 0x2AE6AA

.global sEndingCutsceneOamFrame032
sEndingCutsceneOamFrame032:

baserom_blob 0x2AE6AA, 0x2AE6E2

.global sEndingCutsceneOamFrame033
sEndingCutsceneOamFrame033:

baserom_blob 0x2AE6E2, 0x2AE71A

.global sEndingCutsceneOamFrame034
sEndingCutsceneOamFrame034:

baserom_blob 0x2AE71A, 0x2AE73A

.global sEndingCutsceneOamFrame035
sEndingCutsceneOamFrame035:

baserom_blob 0x2AE73A, 0x2AE75A

.global sEndingCutsceneOamFrame036
sEndingCutsceneOamFrame036:

baserom_blob 0x2AE75A, 0x2AE762

.global sEndingCutsceneOamFrame037
sEndingCutsceneOamFrame037:

baserom_blob 0x2AE762, 0x2AE76A

.global sEndingCutsceneOamFrame038
sEndingCutsceneOamFrame038:

baserom_blob 0x2AE76A, 0x2AE772

.global sEndingCutsceneOamFrame039
sEndingCutsceneOamFrame039:

baserom_blob 0x2AE772, 0x2AE77A

.global sEndingCutsceneOamFrame040
sEndingCutsceneOamFrame040:

baserom_blob 0x2AE77A, 0x2AE782

.global sEndingCutsceneOamFrame041
sEndingCutsceneOamFrame041:

baserom_blob 0x2AE782, 0x2AE78A

.global sEndingCutsceneOamFrame042
sEndingCutsceneOamFrame042:

baserom_blob 0x2AE78A, 0x2AE792

.global sEndingCutsceneOamFrame043
sEndingCutsceneOamFrame043:

baserom_blob 0x2AE792, 0x2AE79A

.global sEndingCutsceneOamFrame044
sEndingCutsceneOamFrame044:

baserom_blob 0x2AE79A, 0x2AE7A2

.global sEndingCutsceneOamFrame045
sEndingCutsceneOamFrame045:

baserom_blob 0x2AE7A2, 0x2AE7AA

.global sEndingCutsceneOamFrame046
sEndingCutsceneOamFrame046:

baserom_blob 0x2AE7AA, 0x2AE7B2

.global sEndingCutsceneOamFrame047
sEndingCutsceneOamFrame047:

baserom_blob 0x2AE7B2, 0x2AE7BA

.global sEndingCutsceneOamFrame048
sEndingCutsceneOamFrame048:

baserom_blob 0x2AE7BA, 0x2AE7C2

.global sEndingCutsceneOamFrame049
sEndingCutsceneOamFrame049:

baserom_blob 0x2AE7C2, 0x2AE7CA

.global sEndingCutsceneOamFrame050
sEndingCutsceneOamFrame050:

baserom_blob 0x2AE7CA, 0x2AE7D2

.global sEndingCutsceneOamFrame051
sEndingCutsceneOamFrame051:

baserom_blob 0x2AE7D2, 0x2AE7DA

.global sEndingCutsceneOamFrame052
sEndingCutsceneOamFrame052:

baserom_blob 0x2AE7DA, 0x2AE7E2

.global sEndingCutsceneOamFrame053
sEndingCutsceneOamFrame053:

baserom_blob 0x2AE7E2, 0x2AE7EA

.global sEndingCutsceneOamFrame054
sEndingCutsceneOamFrame054:

baserom_blob 0x2AE7EA, 0x2AE7F2

.global sEndingCutsceneOamFrame055
sEndingCutsceneOamFrame055:

baserom_blob 0x2AE7F2, 0x2AE7FA

.global sEndingCutsceneOamFrame056
sEndingCutsceneOamFrame056:

baserom_blob 0x2AE7FA, 0x2AE802

.global sEndingCutsceneOamFrame057
sEndingCutsceneOamFrame057:

baserom_blob 0x2AE802, 0x2AE80A

.global sEndingCutsceneOamFrame058
sEndingCutsceneOamFrame058:

baserom_blob 0x2AE80A, 0x2AE812

.global sEndingCutsceneOamFrame059
sEndingCutsceneOamFrame059:

baserom_blob 0x2AE812, 0x2AE81A

.global sEndingCutsceneOamFrame060
sEndingCutsceneOamFrame060:

baserom_blob 0x2AE81A, 0x2AE822

.global sEndingCutsceneOamFrame061
sEndingCutsceneOamFrame061:

baserom_blob 0x2AE822, 0x2AE82A

.global sEndingCutsceneOamFrame062
sEndingCutsceneOamFrame062:

baserom_blob 0x2AE82A, 0x2AE832

.global sEndingCutsceneOamFrame063
sEndingCutsceneOamFrame063:

baserom_blob 0x2AE832, 0x2AE83A

.global sEndingCutsceneOamFrame064
sEndingCutsceneOamFrame064:

baserom_blob 0x2AE83A, 0x2AE842

.global sEndingCutsceneOamFrame065
sEndingCutsceneOamFrame065:

baserom_blob 0x2AE842, 0x2AE84A

.global sEndingCutsceneOamFrame066
sEndingCutsceneOamFrame066:

baserom_blob 0x2AE84A, 0x2AE852

.global sEndingCutsceneOamFrame067
sEndingCutsceneOamFrame067:

baserom_blob 0x2AE852, 0x2AE85A

.global sEndingCutsceneOamFrame068
sEndingCutsceneOamFrame068:

baserom_blob 0x2AE85A, 0x2AE88C

.global sEndingCutsceneOamFrame069
sEndingCutsceneOamFrame069:

baserom_blob 0x2AE88C, 0x2AE8BE

.global sEndingCutsceneOamFrame070
sEndingCutsceneOamFrame070:

baserom_blob 0x2AE8BE, 0x2AE8F0

.global sEndingCutsceneOamFrame071
sEndingCutsceneOamFrame071:

baserom_blob 0x2AE8F0, 0x2AE922

.global sEndingCutsceneOamFrame072
sEndingCutsceneOamFrame072:

baserom_blob 0x2AE922, 0x2AE954

.global sEndingCutsceneOamFrame073
sEndingCutsceneOamFrame073:

baserom_blob 0x2AE954, 0x2AE986

.global sEndingCutsceneOamFrame074
sEndingCutsceneOamFrame074:

baserom_blob 0x2AE986, 0x2AE9B8

.global sEndingCutsceneOamFrame075
sEndingCutsceneOamFrame075:

baserom_blob 0x2AE9B8, 0x2AE9EA

.global sEndingCutsceneOamFrame076
sEndingCutsceneOamFrame076:

baserom_blob 0x2AE9EA, 0x2AE9F8

.global sEndingCutsceneOamFrame077
sEndingCutsceneOamFrame077:

baserom_blob 0x2AE9F8, 0x2AEA06

.global sEndingCutsceneOamFrame078
sEndingCutsceneOamFrame078:

baserom_blob 0x2AEA06, 0x2AEA0E

.global sEndingCutsceneOamFrame079
sEndingCutsceneOamFrame079:

baserom_blob 0x2AEA0E, 0x2AEA16

.global sEndingCutsceneOamFrame080
sEndingCutsceneOamFrame080:

baserom_blob 0x2AEA16, 0x2AEA24

.global sEndingCutsceneOamFrame081
sEndingCutsceneOamFrame081:

baserom_blob 0x2AEA24, 0x2AEA32

.global sEndingCutsceneOamFrame082
sEndingCutsceneOamFrame082:

baserom_blob 0x2AEA32, 0x2AEA40

.global sEndingCutsceneOamFrame083
sEndingCutsceneOamFrame083:

baserom_blob 0x2AEA40, 0x2AEA5A

.global sEndingCutsceneOamFrame084
sEndingCutsceneOamFrame084:

baserom_blob 0x2AEA5A, 0x2AEA74

.global sEndingCutsceneOamFrame085
sEndingCutsceneOamFrame085:

baserom_blob 0x2AEA74, 0x2AEA94

.global sEndingCutsceneOamFrame086
sEndingCutsceneOamFrame086:

baserom_blob 0x2AEA94, 0x2AEAB4

.global sEndingCutsceneOamFrame087
sEndingCutsceneOamFrame087:

baserom_blob 0x2AEAB4, 0x2AEACE

.global sEndingCutsceneOamFrame088
sEndingCutsceneOamFrame088:

baserom_blob 0x2AEACE, 0x2AEAE8

.global sEndingCutsceneOamFrame089
sEndingCutsceneOamFrame089:

baserom_blob 0x2AEAE8, 0x2AEB08

.global sEndingCutsceneOamFrame090
sEndingCutsceneOamFrame090:

baserom_blob 0x2AEB08, 0x2AEB28

.global sEndingCutsceneOamFrame091
sEndingCutsceneOamFrame091:

baserom_blob 0x2AEB28, 0x2AEB42

.global sEndingCutsceneOamFrame092
sEndingCutsceneOamFrame092:

baserom_blob 0x2AEB42, 0x2AEB62

.global sEndingCutsceneOamFrame093
sEndingCutsceneOamFrame093:

baserom_blob 0x2AEB62, 0x2AEB88

.global sEndingCutsceneOamFrame094
sEndingCutsceneOamFrame094:

baserom_blob 0x2AEB88, 0x2AEBAE

.global sEndingCutsceneOamFrame095
sEndingCutsceneOamFrame095:

baserom_blob 0x2AEBAE, 0x2AEBC8

.global sEndingCutsceneOamFrame096
sEndingCutsceneOamFrame096:

baserom_blob 0x2AEBC8, 0x2AEBE2

.global sEndingCutsceneOamFrame097
sEndingCutsceneOamFrame097:

baserom_blob 0x2AEBE2, 0x2AEC08

.global sEndingCutsceneOamFrame098
sEndingCutsceneOamFrame098:

baserom_blob 0x2AEC08, 0x2AEC22

.global sEndingCutsceneOamFrame099
sEndingCutsceneOamFrame099:

baserom_blob 0x2AEC22, 0x2AEC3C

.global sEndingCutsceneOamFrame100
sEndingCutsceneOamFrame100:

baserom_blob 0x2AEC3C, 0x2AEC4A

.global sEndingCutsceneOamFrame101
sEndingCutsceneOamFrame101:

baserom_blob 0x2AEC4A, 0x2AEC58

.global sEndingCutsceneOamFrame102
sEndingCutsceneOamFrame102:

baserom_blob 0x2AEC58, 0x2AEC72

.global sEndingCutsceneOamFrame103
sEndingCutsceneOamFrame103:

baserom_blob 0x2AEC72, 0x2AEC8C

.global sEndingCutsceneOamFrame104
sEndingCutsceneOamFrame104:

baserom_blob 0x2AEC8C, 0x2AECA6

.global sEndingCutsceneOamFrame105
sEndingCutsceneOamFrame105:

baserom_blob 0x2AECA6, 0x2AECC0

.global sEndingCutsceneOamFrame106
sEndingCutsceneOamFrame106:

baserom_blob 0x2AECC0, 0x2AECEC

.global sEndingCutsceneOamFrame107
sEndingCutsceneOamFrame107:

baserom_blob 0x2AECEC, 0x2AED1E

.global sEndingCutsceneOamFrame108
sEndingCutsceneOamFrame108:

baserom_blob 0x2AED1E, 0x2AED3E

.global sEndingCutsceneOamFrame109
sEndingCutsceneOamFrame109:

baserom_blob 0x2AED3E, 0x2AED5E

.global sEndingCutsceneOamFrame110
sEndingCutsceneOamFrame110:

baserom_blob 0x2AED5E, 0x2AED96

.global sEndingCutsceneOamFrame111
sEndingCutsceneOamFrame111:

baserom_blob 0x2AED96, 0x2AEDDA

.global sEndingCutsceneOamFrame112
sEndingCutsceneOamFrame112:

baserom_blob 0x2AEDDA, 0x2AEE1E

.global sEndingCutsceneOamFrame113
sEndingCutsceneOamFrame113:

baserom_blob 0x2AEE1E, 0x2AEE62

.global sEndingCutsceneOamFrame114
sEndingCutsceneOamFrame114:

baserom_blob 0x2AEE62, 0x2AEEA0

.global sEndingCutsceneOamFrame115
sEndingCutsceneOamFrame115:

baserom_blob 0x2AEEA0, 0x2AEED2

.global sEndingCutsceneOamFrame116
sEndingCutsceneOamFrame116:

baserom_blob 0x2AEED2, 0x2AEF04

.global sEndingCutsceneOamFrame117
sEndingCutsceneOamFrame117:

baserom_blob 0x2AEF04, 0x2AEF3C

.global sEndingCutsceneOamFrame118
sEndingCutsceneOamFrame118:

baserom_blob 0x2AEF3C, 0x2AEF74

.global sEndingCutsceneOamFrame119
sEndingCutsceneOamFrame119:

baserom_blob 0x2AEF74, 0x2AEF82

.global sEndingCutsceneOamFrame120
sEndingCutsceneOamFrame120:

baserom_blob 0x2AEF82, 0x2AEF90

.global sEndingCutsceneOamFrame121
sEndingCutsceneOamFrame121:

baserom_blob 0x2AEF90, 0x2AEF9E

.global sEndingCutsceneOamFrame122
sEndingCutsceneOamFrame122:

baserom_blob 0x2AEF9E, 0x2AEFAC

.global sEndingCutsceneOamFrame123
sEndingCutsceneOamFrame123:

baserom_blob 0x2AEFAC, 0x2AEFBA

.global sEndingCutsceneOamFrame124
sEndingCutsceneOamFrame124:

baserom_blob 0x2AEFBA, 0x2AEFC8

.global sEndingCutsceneOamFrame125
sEndingCutsceneOamFrame125:

baserom_blob 0x2AEFC8, 0x2AEFDC

.global sEndingCutsceneOamFrame126
sEndingCutsceneOamFrame126:

baserom_blob 0x2AEFDC, 0x2AEFF0

.global sEndingCutsceneOamFrame127
sEndingCutsceneOamFrame127:

baserom_blob 0x2AEFF0, 0x2AF004

.global sEndingCutsceneOamFrame128
sEndingCutsceneOamFrame128:

baserom_blob 0x2AF004, 0x2AF018

.global sEndingCutsceneOamFrame129
sEndingCutsceneOamFrame129:

baserom_blob 0x2AF018, 0x2AF02C

.global sEndingCutsceneOamFrame130
sEndingCutsceneOamFrame130:

baserom_blob 0x2AF02C, 0x2AF040

.global sEndingCutsceneOamFrame131
sEndingCutsceneOamFrame131:

baserom_blob 0x2AF040, 0x2AF04E

.global sEndingCutsceneOamFrame132
sEndingCutsceneOamFrame132:

baserom_blob 0x2AF04E, 0x2AF062

.global sEndingCutsceneOamFrame133
sEndingCutsceneOamFrame133:

baserom_blob 0x2AF062, 0x2AF07C

.global sEndingCutsceneOamFrame134
sEndingCutsceneOamFrame134:

baserom_blob 0x2AF07C, 0x2AF08A

.global sEndingCutsceneOamFrame135
sEndingCutsceneOamFrame135:

baserom_blob 0x2AF08A, 0x2AF09E

.global sEndingCutsceneOamFrame136
sEndingCutsceneOamFrame136:

baserom_blob 0x2AF09E, 0x2AF0B2

.global sEndingCutsceneOamFrame137
sEndingCutsceneOamFrame137:

baserom_blob 0x2AF0B2, 0x2AF0C0

.global sEndingCutsceneOamFrame138
sEndingCutsceneOamFrame138:

baserom_blob 0x2AF0C0, 0x2AF0CE

.global sEndingCutsceneOamFrame139
sEndingCutsceneOamFrame139:

baserom_blob 0x2AF0CE, 0x2AF0DC

.global sEndingCutsceneOamFrame140
sEndingCutsceneOamFrame140:

baserom_blob 0x2AF0DC, 0x2AF0EA

.global sEndingCutsceneOamFrame141
sEndingCutsceneOamFrame141:

baserom_blob 0x2AF0EA, 0x2AF0FE

.global sEndingCutsceneOamFrame142
sEndingCutsceneOamFrame142:

baserom_blob 0x2AF0FE, 0x2AF118

.global sEndingCutsceneOamFrame143
sEndingCutsceneOamFrame143:

baserom_blob 0x2AF118, 0x2AF14A

.global sEndingCutsceneOamFrame144
sEndingCutsceneOamFrame144:

baserom_blob 0x2AF14A, 0x2AF176

.global sEndingCutsceneOamFrame145
sEndingCutsceneOamFrame145:

baserom_blob 0x2AF176, 0x2AF1A8

.global sEndingCutsceneOamFrame146
sEndingCutsceneOamFrame146:

baserom_blob 0x2AF1A8, 0x2AF1DA

.global sEndingCutsceneOamFrame147
sEndingCutsceneOamFrame147:

baserom_blob 0x2AF1DA, 0x2AF20C

.global sEndingCutsceneOamFrame148
sEndingCutsceneOamFrame148:

baserom_blob 0x2AF20C, 0x2AF238

.global sEndingCutsceneOamFrame149
sEndingCutsceneOamFrame149:

baserom_blob 0x2AF238, 0x2AF26A

.global sEndingCutsceneOamFrame150
sEndingCutsceneOamFrame150:

baserom_blob 0x2AF26A, 0x2AF29C

.global sEndingCutsceneOamFrame151
sEndingCutsceneOamFrame151:

baserom_blob 0x2AF29C, 0x2AF2D4

.global sEndingCutsceneOamFrame152
sEndingCutsceneOamFrame152:

baserom_blob 0x2AF2D4, 0x2AF30C

.global sEndingCutsceneOamFrame153
sEndingCutsceneOamFrame153:

baserom_blob 0x2AF30C, 0x2AF344

.global sEndingCutsceneOamFrame154
sEndingCutsceneOamFrame154:

baserom_blob 0x2AF344, 0x2AF370

.global sEndingCutsceneOamFrame155
sEndingCutsceneOamFrame155:

baserom_blob 0x2AF370, 0x2AF3A2

.global sEndingCutsceneOamFrame156
sEndingCutsceneOamFrame156:

baserom_blob 0x2AF3A2, 0x2AF3D4

.global sEndingCutsceneOamFrame157
sEndingCutsceneOamFrame157:

baserom_blob 0x2AF3D4, 0x2AF406

.global sEndingCutsceneOamFrame158
sEndingCutsceneOamFrame158:

baserom_blob 0x2AF406, 0x2AF432

.global sEndingCutsceneOamFrame159
sEndingCutsceneOamFrame159:

baserom_blob 0x2AF432, 0x2AF464

.global sEndingCutsceneOamFrame160
sEndingCutsceneOamFrame160:

baserom_blob 0x2AF464, 0x2AF496

.global sEndingCutsceneOamFrame161
sEndingCutsceneOamFrame161:

baserom_blob 0x2AF496, 0x2AF4C8

.global sEndingCutsceneOamFrame162
sEndingCutsceneOamFrame162:

baserom_blob 0x2AF4C8, 0x2AF500

.global sEndingCutsceneOamFrame163
sEndingCutsceneOamFrame163:

baserom_blob 0x2AF500, 0x2AF538

.global sEndingCutsceneOamFrame164
sEndingCutsceneOamFrame164:

baserom_blob 0x2AF538, 0x2AF570

.global sEndingCutsceneOamFrame165
sEndingCutsceneOamFrame165:

baserom_blob 0x2AF570, 0x2AF5A8

.global sEndingCutsceneOamFrame166
sEndingCutsceneOamFrame166:

baserom_blob 0x2AF5A8, 0x2AF5DA

.global sEndingCutsceneOamFrame167
sEndingCutsceneOamFrame167:

baserom_blob 0x2AF5DA, 0x2AF612

.global sEndingCutsceneOamFrame168
sEndingCutsceneOamFrame168:

baserom_blob 0x2AF612, 0x2AF64A

.global sEndingCutsceneOamFrame169
sEndingCutsceneOamFrame169:

baserom_blob 0x2AF64A, 0x2AF682

.global sEndingCutsceneOamFrame170
sEndingCutsceneOamFrame170:

baserom_blob 0x2AF682, 0x2AF6B4

.global sEndingCutsceneOamFrame171
sEndingCutsceneOamFrame171:

baserom_blob 0x2AF6B4, 0x2AF6EC

.global sEndingCutsceneOamFrame172
sEndingCutsceneOamFrame172:

baserom_blob 0x2AF6EC, 0x2AF724

.global sEndingCutsceneOamFrame173
sEndingCutsceneOamFrame173:

baserom_blob 0x2AF724, 0x2AF72C

.global sEndingCutsceneOamFrame174
sEndingCutsceneOamFrame174:

baserom_blob 0x2AF72C, 0x2AF734

.global sEndingCutsceneOamFrame175
sEndingCutsceneOamFrame175:

baserom_blob 0x2AF734, 0x2AF73C

.global sEndingCutsceneOamFrame176
sEndingCutsceneOamFrame176:

baserom_blob 0x2AF73C, 0x2AF744

.global sEndingCutsceneOamFrame177
sEndingCutsceneOamFrame177:

baserom_blob 0x2AF744, 0x2AF74C

.global sEndingCutsceneOamFrame178
sEndingCutsceneOamFrame178:

baserom_blob 0x2AF74C, 0x2AF754

.global sEndingCutsceneOamFrame179
sEndingCutsceneOamFrame179:

baserom_blob 0x2AF754, 0x2AF75C

.global sEndingCutsceneOamFrame180
sEndingCutsceneOamFrame180:

baserom_blob 0x2AF75C, 0x2AF77C

.global sEndingCutsceneOamFrame181
sEndingCutsceneOamFrame181:

baserom_blob 0x2AF77C, 0x2AF7B4

.global sEndingCutsceneOamFrame182
sEndingCutsceneOamFrame182:

baserom_blob 0x2AF7B4, 0x2AF7EC

.global sEndingCutsceneOamFrame183
sEndingCutsceneOamFrame183:

baserom_blob 0x2AF7EC, 0x2AF824

.global sEndingCutsceneOamFrame184
sEndingCutsceneOamFrame184:

baserom_blob 0x2AF824, 0x2AF82C

.global sEndingCutsceneOamFrame185
sEndingCutsceneOamFrame185:

baserom_blob 0x2AF82C, 0x2AF834

.global sEndingCutsceneOamFrame186
sEndingCutsceneOamFrame186:

baserom_blob 0x2AF834, 0x2AF83C

.global sEndingCutscenePathData000
sEndingCutscenePathData000:

baserom_blob 0x2AF83C, 0x2AFA58

.global sEndingCutscenePathData001
sEndingCutscenePathData001:

baserom_blob 0x2AFA58, 0x2AFC74

.global sEndingCutscenePathData002
sEndingCutscenePathData002:

baserom_blob 0x2AFC74, 0x2AFE90

.global sEndingCutscenePathData003
sEndingCutscenePathData003:

baserom_blob 0x2AFE90, 0x2B00AC

.global sEndingCutscenePathData004
sEndingCutscenePathData004:

baserom_blob 0x2B00AC, 0x2B02C8

.global sEndingCutscenePathData005
sEndingCutscenePathData005:

baserom_blob 0x2B02C8, 0x2B04E4

.global sEndingCutscenePathData006
sEndingCutscenePathData006:

baserom_blob 0x2B04E4, 0x2B0700

.global sEndingCutscenePathData007
sEndingCutscenePathData007:

baserom_blob 0x2B0700, 0x2B091C

.global sEndingCutscenePathData008
sEndingCutscenePathData008:

baserom_blob 0x2B091C, 0x2B0B38

.global sEndingCutscenePathData009
sEndingCutscenePathData009:

baserom_blob 0x2B0B38, 0x2B0D54

.global sEndingCutscenePathData010
sEndingCutscenePathData010:

baserom_blob 0x2B0D54, 0x2B0F70

.global sEndingCutscenePathData011
sEndingCutscenePathData011:

baserom_blob 0x2B0F70, 0x2B118C

.global sEndingCutscenePathData012
sEndingCutscenePathData012:

baserom_blob 0x2B118C, 0x2B13A8

.global sEndingCutscenePathData013
sEndingCutscenePathData013:

baserom_blob 0x2B13A8, 0x2B15C4

.global sEndingCutscenePathData014
sEndingCutscenePathData014:

baserom_blob 0x2B15C4, 0x2B17E0

.global sEndingCutscenePathData015
sEndingCutscenePathData015:

baserom_blob 0x2B17E0, 0x2B19FC

.global sEndingCutscenePathData016
sEndingCutscenePathData016:

baserom_blob 0x2B19FC, 0x2B1C2C

.global sEndingCutscenePathData017
sEndingCutscenePathData017:

baserom_blob 0x2B1C2C, 0x2B1E5C

.global sEndingCutscenePathData018
sEndingCutscenePathData018:

baserom_blob 0x2B1E5C, 0x2B208C

.global sEndingCutscenePathData019
sEndingCutscenePathData019:

baserom_blob 0x2B208C, 0x2B22BC

.global sEndingCutscenePathData020
sEndingCutscenePathData020:

baserom_blob 0x2B22BC, 0x2B24EC

.global sEndingCutscenePathData021
sEndingCutscenePathData021:

baserom_blob 0x2B24EC, 0x2B271C

.global sEndingCutscenePathData022
sEndingCutscenePathData022:

baserom_blob 0x2B271C, 0x2B294C

.global sEndingCutscenePathData023
sEndingCutscenePathData023:

baserom_blob 0x2B294C, 0x2B2B7C

.global sEndingCutscenePathData024
sEndingCutscenePathData024:

baserom_blob 0x2B2B7C, 0x2B2DAC

.global sEndingCutscenePathData025
sEndingCutscenePathData025:

baserom_blob 0x2B2DAC, 0x2B2FDC

.global sEndingCutscenePathData026
sEndingCutscenePathData026:

baserom_blob 0x2B2FDC, 0x2B320C

.global sEndingCutscenePathData027
sEndingCutscenePathData027:

baserom_blob 0x2B320C, 0x2B343C

.global sEndingCutscenePathData028
sEndingCutscenePathData028:

baserom_blob 0x2B343C, 0x2B366C

.global sEndingCutscenePathData029
sEndingCutscenePathData029:

baserom_blob 0x2B366C, 0x2B389C

.global sEndingCutscenePathData030
sEndingCutscenePathData030:

baserom_blob 0x2B389C, 0x2B3ACC

.global sEndingCutscenePathData031
sEndingCutscenePathData031:

baserom_blob 0x2B3ACC, 0x2B3CFC

.global sEndingCutscenePathData032
sEndingCutscenePathData032:

baserom_blob 0x2B3CFC, 0x2B3F2C

.global sEndingCutscenePathData033
sEndingCutscenePathData033:

baserom_blob 0x2B3F2C, 0x2B415C

.global sEndingCutscenePathData034
sEndingCutscenePathData034:

baserom_blob 0x2B415C, 0x2B438C

.global sEndingCutscenePathData035
sEndingCutscenePathData035:

baserom_blob 0x2B438C, 0x2B45BC

.global sEndingCutscenePathData036
sEndingCutscenePathData036:

baserom_blob 0x2B45BC, 0x2B47EC

.global sEndingCutscenePathData037
sEndingCutscenePathData037:

baserom_blob 0x2B47EC, 0x2B4A1C

.global sEndingCutscenePathData038
sEndingCutscenePathData038:

baserom_blob 0x2B4A1C, 0x2B4C4C

.global sEndingCutscenePathData039
sEndingCutscenePathData039:

baserom_blob 0x2B4C4C, 0x2B4E7C

.global sEndingCutscenePathData040
sEndingCutscenePathData040:

baserom_blob 0x2B4E7C, 0x2B50AC

.global sEndingCutscenePathData041
sEndingCutscenePathData041:

baserom_blob 0x2B50AC, 0x2B52DC

.global sEndingCutscenePathData042
sEndingCutscenePathData042:

baserom_blob 0x2B52DC, 0x2B550C

.global sEndingCutscenePathData043
sEndingCutscenePathData043:

baserom_blob 0x2B550C, 0x2B573C

.global sEndingCutscenePathData044
sEndingCutscenePathData044:

baserom_blob 0x2B573C, 0x2B596C

.global sEndingCutscenePathData045
sEndingCutscenePathData045:

baserom_blob 0x2B596C, 0x2B5B9C

.global sEndingCutscenePathData046
sEndingCutscenePathData046:

baserom_blob 0x2B5B9C, 0x2B5DCC

.global sEndingCutscenePathData047
sEndingCutscenePathData047:

baserom_blob 0x2B5DCC, 0x2B5FFC

.global sEndingCutscenePathData048
sEndingCutscenePathData048:

baserom_blob 0x2B5FFC, 0x2B622E

.global sEndingCutscenePathData049
sEndingCutscenePathData049:

baserom_blob 0x2B622E, 0x2B6460

.global sEndingCutscenePathData050
sEndingCutscenePathData050:

baserom_blob 0x2B6460, 0x2B6692

.global sEndingCutscenePathData051
sEndingCutscenePathData051:

baserom_blob 0x2B6692, 0x2B68C4

.global sEndingCutscenePathData052
sEndingCutscenePathData052:

baserom_blob 0x2B68C4, 0x2B6AF6

.global sEndingCutscenePathData053
sEndingCutscenePathData053:

baserom_blob 0x2B6AF6, 0x2B6D28

.global sEndingCutscenePathData054
sEndingCutscenePathData054:

baserom_blob 0x2B6D28, 0x2B6F5A

.global sEndingCutscenePathData055
sEndingCutscenePathData055:

baserom_blob 0x2B6F5A, 0x2B718C

.global sEndingCutscenePathData056
sEndingCutscenePathData056:

baserom_blob 0x2B718C, 0x2B73BE

.global sEndingCutscenePathData057
sEndingCutscenePathData057:

baserom_blob 0x2B73BE, 0x2B75F0

.global sEndingCutscenePathData058
sEndingCutscenePathData058:

baserom_blob 0x2B75F0, 0x2B7822

.global sEndingCutscenePathData059
sEndingCutscenePathData059:

baserom_blob 0x2B7822, 0x2B7A54

.global sEndingCutscenePathData060
sEndingCutscenePathData060:

baserom_blob 0x2B7A54, 0x2B7C86

.global sEndingCutscenePathData061
sEndingCutscenePathData061:

baserom_blob 0x2B7C86, 0x2B7EB8

.global sEndingCutscenePathData062
sEndingCutscenePathData062:

baserom_blob 0x2B7EB8, 0x2B80EA

.global sEndingCutscenePathData063
sEndingCutscenePathData063:

baserom_blob 0x2B80EA, 0x2B831C

.global sEndingCutscenePathData064
sEndingCutscenePathData064:

baserom_blob 0x2B831C, 0x2B854E

.global sEndingCutscenePathData065
sEndingCutscenePathData065:

baserom_blob 0x2B854E, 0x2B8780

.global sEndingCutscenePathData066
sEndingCutscenePathData066:

baserom_blob 0x2B8780, 0x2B89B2

.global sEndingCutscenePathData067
sEndingCutscenePathData067:

baserom_blob 0x2B89B2, 0x2B8BE4

.global sEndingCutscenePathData068
sEndingCutscenePathData068:

baserom_blob 0x2B8BE4, 0x2B8E16

.global sEndingCutscenePathData069
sEndingCutscenePathData069:

baserom_blob 0x2B8E16, 0x2B9048

.global sEndingCutscenePathData070
sEndingCutscenePathData070:

baserom_blob 0x2B9048, 0x2B927A

.global sEndingCutscenePathData071
sEndingCutscenePathData071:

baserom_blob 0x2B927A, 0x2B94AC

.global sEndingCutscenePathData072
sEndingCutscenePathData072:

baserom_blob 0x2B94AC, 0x2B96DE

.global sEndingCutscenePathData073
sEndingCutscenePathData073:

baserom_blob 0x2B96DE, 0x2B9910

.global sEndingCutscenePathData074
sEndingCutscenePathData074:

baserom_blob 0x2B9910, 0x2B9B42

.global sEndingCutscenePathData075
sEndingCutscenePathData075:

baserom_blob 0x2B9B42, 0x2B9D74

.global sEndingCutscenePathData076
sEndingCutscenePathData076:

baserom_blob 0x2B9D74, 0x2B9FA6

.global sEndingCutscenePathData077
sEndingCutscenePathData077:

baserom_blob 0x2B9FA6, 0x2BA1D8

.global sEndingCutscenePathData078
sEndingCutscenePathData078:

baserom_blob 0x2BA1D8, 0x2BA40A

.global sEndingCutscenePathData079
sEndingCutscenePathData079:

baserom_blob 0x2BA40A, 0x2BA63C

.global sEndingCutscenePathData080
sEndingCutscenePathData080:

baserom_blob 0x2BA63C, 0x2BA86E

.global sEndingCutscenePathData081
sEndingCutscenePathData081:

baserom_blob 0x2BA86E, 0x2BAAA0

.global sEndingCutscenePathData082
sEndingCutscenePathData082:

baserom_blob 0x2BAAA0, 0x2BACD2

.global sEndingCutscenePathData083
sEndingCutscenePathData083:

baserom_blob 0x2BACD2, 0x2BAF04

.global sEndingCutscenePathData084
sEndingCutscenePathData084:

baserom_blob 0x2BAF04, 0x2BB136

.global sEndingCutscenePathData085
sEndingCutscenePathData085:

baserom_blob 0x2BB136, 0x2BB368

.global sEndingCutscenePathData086
sEndingCutscenePathData086:

baserom_blob 0x2BB368, 0x2BB59A

.global sEndingCutscenePathData087
sEndingCutscenePathData087:

baserom_blob 0x2BB59A, 0x2BB7CC

.global sEndingCutscenePathData088
sEndingCutscenePathData088:

baserom_blob 0x2BB7CC, 0x2BB9FE

.global sEndingCutscenePathData089
sEndingCutscenePathData089:

baserom_blob 0x2BB9FE, 0x2BBC30

.global sEndingCutscenePathData090
sEndingCutscenePathData090:

baserom_blob 0x2BBC30, 0x2BBE62

.global sEndingCutscenePathData091
sEndingCutscenePathData091:

baserom_blob 0x2BBE62, 0x2BC094

.global sEndingCutscenePathData092
sEndingCutscenePathData092:

baserom_blob 0x2BC094, 0x2BC2C6

.global sEndingCutscenePathData093
sEndingCutscenePathData093:

baserom_blob 0x2BC2C6, 0x2BC4F8

.global sEndingCutscenePathData094
sEndingCutscenePathData094:

baserom_blob 0x2BC4F8, 0x2BC72A

.global sEndingCutscenePathData095
sEndingCutscenePathData095:

baserom_blob 0x2BC72A, 0x2BC95C

.global sEndingCutscenePathData096
sEndingCutscenePathData096:

baserom_blob 0x2BC95C, 0x2BCB8E

.global sEndingCutscenePathData097
sEndingCutscenePathData097:

baserom_blob 0x2BCB8E, 0x2BCDC0

.global sEndingCutscenePathData098
sEndingCutscenePathData098:

baserom_blob 0x2BCDC0, 0x2BCFF2

.global sEndingCutscenePathData099
sEndingCutscenePathData099:

baserom_blob 0x2BCFF2, 0x2BD224

.global sEndingCutscenePathData100
sEndingCutscenePathData100:

baserom_blob 0x2BD224, 0x2BD456

.global sEndingCutscenePathData101
sEndingCutscenePathData101:

baserom_blob 0x2BD456, 0x2BD688

.global sEndingCutscenePathData102
sEndingCutscenePathData102:

baserom_blob 0x2BD688, 0x2BD8BA

.global sEndingCutscenePathData103
sEndingCutscenePathData103:

baserom_blob 0x2BD8BA, 0x2BDAEC

.global sEndingCutscenePathData104
sEndingCutscenePathData104:

baserom_blob 0x2BDAEC, 0x2BDD1E

.global sEndingCutscenePathData105
sEndingCutscenePathData105:

baserom_blob 0x2BDD1E, 0x2BDF50

.global sEndingCutscenePathData106
sEndingCutscenePathData106:

baserom_blob 0x2BDF50, 0x2BE182

.global sEndingCutscenePathData107
sEndingCutscenePathData107:

baserom_blob 0x2BE182, 0x2BE3B4

.global sEndingCutscenePathData108
sEndingCutscenePathData108:

baserom_blob 0x2BE3B4, 0x2BE5E6

.global sEndingCutscenePathData109
sEndingCutscenePathData109:

baserom_blob 0x2BE5E6, 0x2BE818

.global sEndingCutscenePathData110
sEndingCutscenePathData110:

baserom_blob 0x2BE818, 0x2BEA4A

.global sEndingCutscenePathData111
sEndingCutscenePathData111:

baserom_blob 0x2BEA4A, 0x2BEC7C

.global sEndingCutscenePathData112
sEndingCutscenePathData112:

baserom_blob 0x2BEC7C, 0x2BEEAE

.global sEndingCutscenePathData113
sEndingCutscenePathData113:

baserom_blob 0x2BEEAE, 0x2BF0E0

.global sEndingCutscenePathData114
sEndingCutscenePathData114:

baserom_blob 0x2BF0E0, 0x2BF312

.global sEndingCutscenePathData115
sEndingCutscenePathData115:

baserom_blob 0x2BF312, 0x2BF544

.global sEndingCutscenePathData116
sEndingCutscenePathData116:

baserom_blob 0x2BF544, 0x2BF776

.global sEndingCutscenePathData117
sEndingCutscenePathData117:

baserom_blob 0x2BF776, 0x2BF9A8

.global sEndingCutscenePathData118
sEndingCutscenePathData118:

baserom_blob 0x2BF9A8, 0x2BFBDA

.global sEndingCutscenePathData119
sEndingCutscenePathData119:

baserom_blob 0x2BFBDA, 0x2BFE0C

.global sEndingCutscenePathData120
sEndingCutscenePathData120:

baserom_blob 0x2BFE0C, 0x2C003E

.global sEndingCutscenePathData121
sEndingCutscenePathData121:

baserom_blob 0x2C003E, 0x2C0270

.global sEndingCutscenePathData122
sEndingCutscenePathData122:

baserom_blob 0x2C0270, 0x2C04A2

.global sEndingCutscenePathData123
sEndingCutscenePathData123:

baserom_blob 0x2C04A2, 0x2C06D4

.global sEndingCutscenePathData124
sEndingCutscenePathData124:

baserom_blob 0x2C06D4, 0x2C0906

.global sEndingCutscenePathData125
sEndingCutscenePathData125:

baserom_blob 0x2C0906, 0x2C0B38

.global sEndingCutscenePathData126
sEndingCutscenePathData126:

baserom_blob 0x2C0B38, 0x2C0D6A

.global sEndingCutscenePathData127
sEndingCutscenePathData127:

baserom_blob 0x2C0D6A, 0x2C0F9C

.global sEndingCutscenePathData128
sEndingCutscenePathData128:

baserom_blob 0x2C0F9C, 0x2C11CE

.global sEndingCutscenePathData129
sEndingCutscenePathData129:

baserom_blob 0x2C11CE, 0x2C1400

.global sEndingCutscenePathData130
sEndingCutscenePathData130:

baserom_blob 0x2C1400, 0x2C1632

.global sEndingCutscenePathData131
sEndingCutscenePathData131:

baserom_blob 0x2C1632, 0x2C1864

.global sEndingCutscenePathData132
sEndingCutscenePathData132:

baserom_blob 0x2C1864, 0x2C1A96

.global sEndingCutscenePathData133
sEndingCutscenePathData133:

baserom_blob 0x2C1A96, 0x2C1CC8

.global sEndingCutscenePathData134
sEndingCutscenePathData134:

baserom_blob 0x2C1CC8, 0x2C1EFA

.global sEndingCutscenePathData135
sEndingCutscenePathData135:

baserom_blob 0x2C1EFA, 0x2C212C

.global sEndingCutscenePathData136
sEndingCutscenePathData136:

baserom_blob 0x2C212C, 0x2C235E

.global sEndingCutscenePathData137
sEndingCutscenePathData137:

baserom_blob 0x2C235E, 0x2C2590

.global sEndingCutscenePathData138
sEndingCutscenePathData138:

baserom_blob 0x2C2590, 0x2C27C2

.global sEndingCutscenePathData139
sEndingCutscenePathData139:

baserom_blob 0x2C27C2, 0x2C29F4

.global sEndingCutscenePathData140
sEndingCutscenePathData140:

baserom_blob 0x2C29F4, 0x2C2C26

.global sEndingCutscenePathData141
sEndingCutscenePathData141:

baserom_blob 0x2C2C26, 0x2C2E58

.global sEndingCutscenePathData142
sEndingCutscenePathData142:

baserom_blob 0x2C2E58, 0x2C308A

.global sEndingCutscenePathData143
sEndingCutscenePathData143:

baserom_blob 0x2C308A, 0x2C6128

.global sEndingCutscenePathData144
sEndingCutscenePathData144:

baserom_blob 0x2C6128, 0x2C64D0

.global sEndingCutscenePathData145
sEndingCutscenePathData145:

baserom_blob 0x2C64D0, 0x2C6878

.global sEndingCutscenePathData146
sEndingCutscenePathData146:

baserom_blob 0x2C6878, 0x2C6C20

.global sEndingCutscenePathData147
sEndingCutscenePathData147:

baserom_blob 0x2C6C20, 0x2C6FC8

.global sEndingCutscenePathData148
sEndingCutscenePathData148:

baserom_blob 0x2C6FC8, 0x2C7370

.global sEndingCutscenePathData149
sEndingCutscenePathData149:

baserom_blob 0x2C7370, 0x2C7718

.global sEndingCutscenePathData150
sEndingCutscenePathData150:

baserom_blob 0x2C7718, 0x2C7AC0

.global sEndingCutscenePathData151
sEndingCutscenePathData151:

baserom_blob 0x2C7AC0, 0x2C7E68

.global sEndingCutscenePathData152
sEndingCutscenePathData152:

baserom_blob 0x2C7E68, 0x2C8062

.global sEndingCutscenePathData153
sEndingCutscenePathData153:

baserom_blob 0x2C8062, 0x2C825C

.global sEndingCutscenePathData154
sEndingCutscenePathData154:

baserom_blob 0x2C825C, 0x2C8476

.global sEndingCutscenePathData155
sEndingCutscenePathData155:

baserom_blob 0x2C8476, 0x2C8690

.global sEndingCutscenePathData156
sEndingCutscenePathData156:

baserom_blob 0x2C8690, 0x2C889A

.global sEndingCutscenePathData157
sEndingCutscenePathData157:

baserom_blob 0x2C889A, 0x2C8AA4

.global sEndingCutscenePathData158
sEndingCutscenePathData158:

baserom_blob 0x2C8AA4, 0x2C8CD0

.global sEndingCutscenePathData159
sEndingCutscenePathData159:

baserom_blob 0x2C8CD0, 0x2C8EFC

.global sEndingCutscenePathData160
sEndingCutscenePathData160:

baserom_blob 0x2C8EFC, 0x2C90FE

.global sEndingCutscenePathData161
sEndingCutscenePathData161:

baserom_blob 0x2C90FE, 0x2C9300

.global sEndingCutscenePathData162
sEndingCutscenePathData162:

baserom_blob 0x2C9300, 0x2C9522

.global sEndingCutscenePathData163
sEndingCutscenePathData163:

baserom_blob 0x2C9522, 0x2C9744

.global sEndingCutscenePathData164
sEndingCutscenePathData164:

baserom_blob 0x2C9744, 0x2C9956

.global sEndingCutscenePathData165
sEndingCutscenePathData165:

baserom_blob 0x2C9956, 0x2C9B68

.global sEndingCutscenePathData166
sEndingCutscenePathData166:

baserom_blob 0x2C9B68, 0x2C9D9A

.global sEndingCutscenePathData167
sEndingCutscenePathData167:

baserom_blob 0x2C9D9A, 0x2C9FCC

.global sUnk_82C9FCC
sUnk_82C9FCC:

baserom_blob 0x2C9FCC, 0x2CA00C

.global sUnk_82CA00C
sUnk_82CA00C:

baserom_blob 0x2CA00C, 0x2CAC74

.global sUnk_82CAC74
sUnk_82CAC74:

baserom_blob 0x2CAC74, 0x2CAD88

.global sUnk_82CAD88
sUnk_82CAD88:

baserom_blob 0x2CAD88, 0x2CAEE6

.global sUnk_82CAEE6
sUnk_82CAEE6:

baserom_blob 0x2CAEE6, 0x2CAF08

.global sUnk_82CAF08
sUnk_82CAF08:

baserom_blob 0x2CAF08, 0x2CBD78

.global sUnk_82CBD78
sUnk_82CBD78:

baserom_blob 0x2CBD78, 0x2CBE44

.global sUnk_82CBE44
sUnk_82CBE44:

baserom_blob 0x2CBE44, 0x2CD390

.global sUnk_82CD390
sUnk_82CD390:

baserom_blob 0x2CD390, 0x2CD4B4

.global sUnk_82CD4B4
sUnk_82CD4B4:

baserom_blob 0x2CD4B4, 0x2CE390

.global sUnk_82CE390
sUnk_82CE390:

baserom_blob 0x2CE390, 0x2CE4B4

.global sUnk_82CE4B4
sUnk_82CE4B4:

baserom_blob 0x2CE4B4, 0x2CE598

.global sUnk_82CE598
sUnk_82CE598:

baserom_blob 0x2CE598, 0x2CE704

.global sUnk_82CE704
sUnk_82CE704:

baserom_blob 0x2CE704, 0x2CFA14

.global sUnk_82CFA14
sUnk_82CFA14:

baserom_blob 0x2CFA14, 0x2CFB22

.global sUnk_82CFB22
sUnk_82CFB22:

baserom_blob 0x2CFB22, 0x2CFB44

.global sUnk_82CFB44
sUnk_82CFB44:

baserom_blob 0x2CFB44, 0x2D0F64

.global sUnk_82D0F64
sUnk_82D0F64:

baserom_blob 0x2D0F64, 0x2D1060

.global sUnk_82D1060
sUnk_82D1060:

baserom_blob 0x2D1060, 0x2D239C

.global sUnk_82D239C
sUnk_82D239C:

baserom_blob 0x2D239C, 0x2D248E

.global sUnk_82D248E
sUnk_82D248E:

baserom_blob 0x2D248E, 0x2D24B0

.global sUnk_82D24B0
sUnk_82D24B0:

baserom_blob 0x2D24B0, 0x2D270C

//-----

.global sUnk_82D270C
sUnk_82D270C:

baserom_blob 0x2D270C, 0x2D2714

.global sUnk_82D2714
sUnk_82D2714:

baserom_blob 0x2D2714, 0x2D2722

.global sUnk_82D2722
sUnk_82D2722:

baserom_blob 0x2D2722, 0x2D272A

.global sUnk_82D272A
sUnk_82D272A:

baserom_blob 0x2D272A, 0x2D2738

.global sUnk_82D2738
sUnk_82D2738:

baserom_blob 0x2D2738, 0x2D2746

.global sUnk_82D2746
sUnk_82D2746:

baserom_blob 0x2D2746, 0x2D275A

.global sUnk_82D275A
sUnk_82D275A:

baserom_blob 0x2D275A, 0x2D276E

.global sUnk_82D276E
sUnk_82D276E:

baserom_blob 0x2D276E, 0x2D2788

.global sUnk_82D2788
sUnk_82D2788:

baserom_blob 0x2D2788, 0x2D27B4

.global sUnk_82D27B4
sUnk_82D27B4:

baserom_blob 0x2D27B4, 0x2D27E0

.global sUnk_82D27E0
sUnk_82D27E0:

baserom_blob 0x2D27E0, 0x2D2812

.global sUnk_82D2812
sUnk_82D2812:

baserom_blob 0x2D2812, 0x2D283E

.global sUnk_82D283E
sUnk_82D283E:

baserom_blob 0x2D283E, 0x2D286A

.global sUnk_82D286A
sUnk_82D286A:

baserom_blob 0x2D286A, 0x2D289C

.global sUnk_82D289C
sUnk_82D289C:

baserom_blob 0x2D289C, 0x2D28D4

.global sUnk_82D28D4
sUnk_82D28D4:

baserom_blob 0x2D28D4, 0x2D2912

.global sUnk_82D2912
sUnk_82D2912:

baserom_blob 0x2D2912, 0x2D2956

.global sUnk_82D2956
sUnk_82D2956:

baserom_blob 0x2D2956, 0x2D2976

.global sUnk_82D2976
sUnk_82D2976:

baserom_blob 0x2D2976, 0x2D297E

.global sUnk_82D297E
sUnk_82D297E:

baserom_blob 0x2D297E, 0x2D298C

.global sUnk_82D298C
sUnk_82D298C:

baserom_blob 0x2D298C, 0x2D2994

.global sUnk_82D2994
sUnk_82D2994:

baserom_blob 0x2D2994, 0x2D29A2

.global sUnk_82D29A2
sUnk_82D29A2:

baserom_blob 0x2D29A2, 0x2D29B0

.global sUnk_82D29B0
sUnk_82D29B0:

baserom_blob 0x2D29B0, 0x2D29BE

.global sUnk_82D29BE
sUnk_82D29BE:

baserom_blob 0x2D29BE, 0x2D29D2

.global sUnk_82D29D2
sUnk_82D29D2:

baserom_blob 0x2D29D2, 0x2D29E6

.global sUnk_82D29E6
sUnk_82D29E6:

baserom_blob 0x2D29E6, 0x2D2A00

.global sUnk_82D2A00
sUnk_82D2A00:

baserom_blob 0x2D2A00, 0x2D2A20

.global sUnk_82D2A20
sUnk_82D2A20:

baserom_blob 0x2D2A20, 0x2D2A46

.global sUnk_82D2A46
sUnk_82D2A46:

baserom_blob 0x2D2A46, 0x2D40F4

.global sUnk_82D40F4
sUnk_82D40F4:

baserom_blob 0x2D40F4, 0x2D41D4

.global sUnk_82D41D4
sUnk_82D41D4:

baserom_blob 0x2D41D4, 0x2D820C

.global sUnk_82D820C
sUnk_82D820C:

baserom_blob 0x2D820C, 0x2D825E

.global sUnk_82D825E
sUnk_82D825E:

baserom_blob 0x2D825E, 0x2D8278

.global sUnk_82D8278
sUnk_82D8278:

baserom_blob 0x2D8278, 0x2D8292

.global sUnk_82D8292
sUnk_82D8292:

baserom_blob 0x2D8292, 0x2D82D0

.global sUnk_82D82D0
sUnk_82D82D0:

baserom_blob 0x2D82D0, 0x2D830E

.global sUnk_82D830E
sUnk_82D830E:

baserom_blob 0x2D830E, 0x2D8390

.global sUnk_82D8390
sUnk_82D8390:

baserom_blob 0x2D8390, 0x2D9028

//-----

.global sTitleScreenSHardLogoFrame0Oam
sTitleScreenSHardLogoFrame0Oam:

baserom_blob 0x2D9028, 0x2D9042

.global sTitleScreenSHardLogoFrame1Oam
sTitleScreenSHardLogoFrame1Oam:

baserom_blob 0x2D9042, 0x2D905C

.global sTitleScreenNormalLogoFrame0Oam
sTitleScreenNormalLogoFrame0Oam:

baserom_blob 0x2D905C, 0x2D9076

.global sTitleScreenNormalLogoFrame1Oam
sTitleScreenNormalLogoFrame1Oam:

baserom_blob 0x2D9076, 0x2D9090

.global sTitleScreenNormalLogoFrame2Oam
sTitleScreenNormalLogoFrame2Oam:

baserom_blob 0x2D9090, 0x2D90AA

.global sTitleScreenNormalLogoIdleOam
sTitleScreenNormalLogoIdleOam:

baserom_blob 0x2D90AA, 0x2D90C4

.global sTitleScreenOverlayFrame00Oam
sTitleScreenOverlayFrame00Oam:

baserom_blob 0x2D90C4, 0x2D90EA

.global sTitleScreenOverlayFrame01Oam
sTitleScreenOverlayFrame01Oam:

baserom_blob 0x2D90EA, 0x2D9116

.global sTitleScreenOverlayFrame02Oam
sTitleScreenOverlayFrame02Oam:

baserom_blob 0x2D9116, 0x2D9142

.global sTitleScreenOverlayFrame03Oam
sTitleScreenOverlayFrame03Oam:

baserom_blob 0x2D9142, 0x2D917A

.global sTitleScreenOverlayFrame04Oam
sTitleScreenOverlayFrame04Oam:

baserom_blob 0x2D917A, 0x2D91B8

.global sTitleScreenOverlayFrame05Oam
sTitleScreenOverlayFrame05Oam:

baserom_blob 0x2D91B8, 0x2D9202

.global sTitleScreenOverlayFrame06Oam
sTitleScreenOverlayFrame06Oam:

baserom_blob 0x2D9202, 0x2D9258

.global sTitleScreenOverlayFrame07Oam
sTitleScreenOverlayFrame07Oam:

baserom_blob 0x2D9258, 0x2D92AE

.global sTitleScreenOverlayFrame08Oam
sTitleScreenOverlayFrame08Oam:

baserom_blob 0x2D92AE, 0x2D9304

.global sTitleScreenOverlayFrame09Oam
sTitleScreenOverlayFrame09Oam:

baserom_blob 0x2D9304, 0x2D9354

.global sTitleScreenOverlayFrame10Oam
sTitleScreenOverlayFrame10Oam:

baserom_blob 0x2D9354, 0x2D93BC

.global sTitleScreenOverlayFrame11Oam
sTitleScreenOverlayFrame11Oam:

baserom_blob 0x2D93BC, 0x2D9430

.global sTitleScreenOverlayFrame12Oam
sTitleScreenOverlayFrame12Oam:

baserom_blob 0x2D9430, 0x2D94A4

.global sTitleScreenOverlayFrame13Oam
sTitleScreenOverlayFrame13Oam:

baserom_blob 0x2D94A4, 0x2D9512

.global sTitleScreenOverlayFrame14Oam
sTitleScreenOverlayFrame14Oam:

baserom_blob 0x2D9512, 0x2D9580

.global sTitleScreenOverlayFrame15Oam
sTitleScreenOverlayFrame15Oam:

baserom_blob 0x2D9580, 0x2D95D6

.global sTitleScreenOverlayFrame16Oam
sTitleScreenOverlayFrame16Oam:

baserom_blob 0x2D95D6, 0x2D9620

.global sTitleScreenOverlayFrame17Oam
sTitleScreenOverlayFrame17Oam:

baserom_blob 0x2D9620, 0x2D965E

.global sTitleScreenOverlayFrame18Oam
sTitleScreenOverlayFrame18Oam:

baserom_blob 0x2D965E, 0x2D96A8

.global sTitleScreenOverlayFrame19Oam
sTitleScreenOverlayFrame19Oam:

baserom_blob 0x2D96A8, 0x2D96EC

.global sTitleScreenOverlayFrame20Oam
sTitleScreenOverlayFrame20Oam:

baserom_blob 0x2D96EC, 0x2D9730

.global sTitleScreenOverlayFrame21Oam
sTitleScreenOverlayFrame21Oam:

baserom_blob 0x2D9730, 0x2D9774

.global sTitleScreenOverlayFrame22Oam
sTitleScreenOverlayFrame22Oam:

baserom_blob 0x2D9774, 0x2D97B8

.global sTitleScreenOverlayFrame23Oam
sTitleScreenOverlayFrame23Oam:

baserom_blob 0x2D97B8, 0x2D97F6

.global sTitleScreenOverlayFrame24Oam
sTitleScreenOverlayFrame24Oam:

baserom_blob 0x2D97F6, 0x2D983A

.global sTitleScreenOverlayFrame25Oam
sTitleScreenOverlayFrame25Oam:

baserom_blob 0x2D983A, 0x2D9878

.global sTitleScreenOverlayFrame26Oam
sTitleScreenOverlayFrame26Oam:

baserom_blob 0x2D9878, 0x2D98BC

.global sTitleScreenOverlayFrame27Oam
sTitleScreenOverlayFrame27Oam:

baserom_blob 0x2D98BC, 0x2D98FA

.global sTitleScreenOverlayFrame28Oam
sTitleScreenOverlayFrame28Oam:

baserom_blob 0x2D98FA, 0x2D9932

.global sTitleScreenOverlayFrame29Oam
sTitleScreenOverlayFrame29Oam:

baserom_blob 0x2D9932, 0x2D9964

.global sTitleScreenOverlayFrame30Oam
sTitleScreenOverlayFrame30Oam:

baserom_blob 0x2D9964, 0x2D9990

.global sTitleScreenOverlayFrame31Oam
sTitleScreenOverlayFrame31Oam:

baserom_blob 0x2D9990, 0x2D99BC

.global sTitleScreenOverlayFrame32Oam
sTitleScreenOverlayFrame32Oam:

baserom_blob 0x2D99BC, 0x2D99E2

.global sTitleScreenOverlayFrame33Oam
sTitleScreenOverlayFrame33Oam:

baserom_blob 0x2D99E2, 0x2D9A08

.global sTitleScreenOverlayFrame34Oam
sTitleScreenOverlayFrame34Oam:

baserom_blob 0x2D9A08, 0x2D9A28

.global sTitleScreenOverlayFrame35Oam
sTitleScreenOverlayFrame35Oam:

baserom_blob 0x2D9A28, 0x2D9A48

.global sTitleScreenOverlayFrame36Oam
sTitleScreenOverlayFrame36Oam:

baserom_blob 0x2D9A48, 0x2D9A68

.global sTitleScreenOverlayFrame37Oam
sTitleScreenOverlayFrame37Oam:

baserom_blob 0x2D9A68, 0x2D9A8E

.global sTitleScreenOverlayFrame38Oam
sTitleScreenOverlayFrame38Oam:

baserom_blob 0x2D9A8E, 0x2D9AB4

.global sTitleScreenOverlayFrame39Oam
sTitleScreenOverlayFrame39Oam:

baserom_blob 0x2D9AB4, 0x2D9ADA

.global sTitleScreenOverlayFrame40Oam
sTitleScreenOverlayFrame40Oam:

baserom_blob 0x2D9ADA, 0x2D9B00

.global sTitleScreenOverlayFrame41Oam
sTitleScreenOverlayFrame41Oam:

baserom_blob 0x2D9B00, 0x2D9B26

.global sTitleScreenOverlayFrame42Oam
sTitleScreenOverlayFrame42Oam:

baserom_blob 0x2D9B26, 0x2D9B4C

.global sTitleScreenOverlayFrame43Oam
sTitleScreenOverlayFrame43Oam:

baserom_blob 0x2D9B4C, 0x2D9B72

.global sTitleScreenOverlayFrame44Oam
sTitleScreenOverlayFrame44Oam:

baserom_blob 0x2D9B72, 0x2D9B98

.global sTitleScreenOverlayFrame45Oam
sTitleScreenOverlayFrame45Oam:

baserom_blob 0x2D9B98, 0x2D9BBE

.global sTitleScreenOverlayFrame46Oam
sTitleScreenOverlayFrame46Oam:

baserom_blob 0x2D9BBE, 0x2D9BDE

.global sTitleScreenOverlayFrame47Oam
sTitleScreenOverlayFrame47Oam:

baserom_blob 0x2D9BDE, 0x2D9BFE

.global sTitleScreenOverlayFrame48Oam
sTitleScreenOverlayFrame48Oam:

baserom_blob 0x2D9BFE, 0x2D9C1E

.global sTitleScreenOverlayFrame49Oam
sTitleScreenOverlayFrame49Oam:

baserom_blob 0x2D9C1E, 0x2D9C3E

.global sTitleScreenOverlayFrame50Oam
sTitleScreenOverlayFrame50Oam:

baserom_blob 0x2D9C3E, 0x2D9C5E

.global sTitleScreenOverlayFrame51Oam
sTitleScreenOverlayFrame51Oam:

baserom_blob 0x2D9C5E, 0x2D9C78

.global sUnk_82D9C78
sUnk_82D9C78:

baserom_blob 0x2D9C78, 0x2D9D18

.global sUnk_82D9D18
sUnk_82D9D18:

baserom_blob 0x2D9D18, 0x2DC454

.global sUnk_82DC454
sUnk_82DC454:

baserom_blob 0x2DC454, 0x2DC66E

.global sUnk_82DC66E
sUnk_82DC66E:

baserom_blob 0x2DC66E, 0x2DC738

.global sUnk_82DC738
sUnk_82DC738:

baserom_blob 0x2DC738, 0x2DC7EA

.global sUnk_82DC7EA
sUnk_82DC7EA:

baserom_blob 0x2DC7EA, 0x2DC878

.global sUnk_82DC878
sUnk_82DC878:

baserom_blob 0x2DC878, 0x2DC902

.global sUnk_82DC902
sUnk_82DC902:

baserom_blob 0x2DC902, 0x2DCBA4

.global sUnk_82DCBA4
sUnk_82DCBA4:

baserom_blob 0x2DCBA4, 0x2DCD16

.global sUnk_82DCD16
sUnk_82DCD16:

baserom_blob 0x2DCD16, 0x2DCDC8

.global sUnk_82DCDC8
sUnk_82DCDC8:

baserom_blob 0x2DCDC8, 0x2DCE4A

.global sUnk_82DCE4A
sUnk_82DCE4A:

baserom_blob 0x2DCE4A, 0x2DCFCC

.global sUnk_82DCFCC
sUnk_82DCFCC:

baserom_blob 0x2DCFCC, 0x2DD0A8

//-----

.global sStartingWarioData
sStartingWarioData:

baserom_blob 0x2DD0A8, 0x2DD0E4

.global sStartingHeartMeter
sStartingHeartMeter:

baserom_blob 0x2DD0E4, 0x2DD0E8

.global sStartingHeartGauge
sStartingHeartGauge:

baserom_blob 0x2DD0E8, 0x2DD0EC

.global sUnk_82DD0EC
sUnk_82DD0EC:

baserom_blob 0x2DD0EC, 0x2DD0F4

.global sStartingWarioEffect
sStartingWarioEffect:

baserom_blob 0x2DD0F4, 0x2DD0FC

.global sEmptyCarriedSprite
sEmptyCarriedSprite:

baserom_blob 0x2DD0FC, 0x2DD104

.global sEmptyDustEffect
sEmptyDustEffect:

baserom_blob 0x2DD104, 0x2DD110

.global sUnk_82DD110
sUnk_82DD110:

baserom_blob 0x2DD110, 0x2DD388

.global sUnk_82DD388
sUnk_82DD388:

baserom_blob 0x2DD388, 0x2DD3D0

.global sUnk_82DD3D0
sUnk_82DD3D0:

baserom_blob 0x2DD3D0, 0x2DD3F8

.global sUnk_82DD3F8
sUnk_82DD3F8:

baserom_blob 0x2DD3F8, 0x2DD428

.global sUnk_82DD428
sUnk_82DD428:

baserom_blob 0x2DD428, 0x2DD430

.global sUnk_82DD430
sUnk_82DD430:

baserom_blob 0x2DD430, 0x2DD6A8

.global sUnk_82DD6A8
sUnk_82DD6A8:

baserom_blob 0x2DD6A8, 0x2DD728

.global sUnk_82DD728
sUnk_82DD728:

baserom_blob 0x2DD728, 0x2DD730

.global sUnk_82DD730
sUnk_82DD730:

baserom_blob 0x2DD730, 0x2DD7B0

.global sFlamingWarioGraphicsTable
sFlamingWarioGraphicsTable:

baserom_blob 0x2DD7B0, 0x2DD800

.global sFlamingWarioPoseProperties
sFlamingWarioPoseProperties:

baserom_blob 0x2DD800, 0x2DD850

.global sFatWarioGraphicsTable
sFatWarioGraphicsTable:

baserom_blob 0x2DD850, 0x2DD8A8

.global sFatWarioPoseProperties
sFatWarioPoseProperties:

baserom_blob 0x2DD8A8, 0x2DD900

.global sFrozenGraphicsTable
sFrozenGraphicsTable:

baserom_blob 0x2DD900, 0x2DD920

.global sFrozenPoseData
sFrozenPoseData:

baserom_blob 0x2DD920, 0x2DD940

.global sZombieWarioGraphicsTable
sZombieWarioGraphicsTable:

baserom_blob 0x2DD940, 0x2DD9A8

.global sZombieWarioPoseProperties
sZombieWarioPoseProperties:

baserom_blob 0x2DD9A8, 0x2DDA10

.global sSnowmanWarioAnimationTable
sSnowmanWarioAnimationTable:

baserom_blob 0x2DDA10, 0x2DDA90

.global sSnowmanWarioPoseProperties
sSnowmanWarioPoseProperties:

baserom_blob 0x2DDA90, 0x2DDB10

.global sUnk_82DDB10
sUnk_82DDB10:

baserom_blob 0x2DDB10, 0x2DDB60

.global sUnk_82DDB60
sUnk_82DDB60:

baserom_blob 0x2DDB60, 0x2DDBB0

.global sPuffyGraphicsTable
sPuffyGraphicsTable:

baserom_blob 0x2DDBB0, 0x2DDBD0

.global sPuffyPoseData
sPuffyPoseData:

baserom_blob 0x2DDBD0, 0x2DDBF0

.global sBatGraphicsTable
sBatGraphicsTable:

baserom_blob 0x2DDBF0, 0x2DDC18

.global sBatPoseData
sBatPoseData:

baserom_blob 0x2DDC18, 0x2DDC40

.global sFlatWarioAnimationTable
sFlatWarioAnimationTable:

baserom_blob 0x2DDC40, 0x2DDC78

.global sFlatWarioPoseProperties
sFlatWarioPoseProperties:

baserom_blob 0x2DDC78, 0x2DDCB0

.global sMaskWarioGraphicsTable
sMaskWarioGraphicsTable:

baserom_blob 0x2DDCB0, 0x2DDCC0

.global sMaskWarioPoseProperties
sMaskWarioPoseProperties:

baserom_blob 0x2DDCC0, 0x2DDCD0

.global sUnk_82DDCD0
sUnk_82DDCD0:

baserom_blob 0x2DDCD0, 0x2DDCF0

.global sUnk_82DDCF0
sUnk_82DDCF0:

baserom_blob 0x2DDCF0, 0x2DDD20

.global sWarioEffectsGfx
sWarioEffectsGfx:

baserom_blob 0x2DDD20, 0x2DDDA0

.global sWarioDefaultObjPalette
sWarioDefaultObjPalette:

baserom_blob 0x2DDDA0, 0x2DDDC0

.global sUnk_82DDDC0
sUnk_82DDDC0:

baserom_blob 0x2DDDC0, 0x2DDDE0

.global sUnk_82DDDE0
sUnk_82DDDE0:

baserom_blob 0x2DDDE0, 0x2DDFE0

.global sUnk_82DDFE0
sUnk_82DDFE0:

baserom_blob 0x2DDFE0, 0x2DE3A0

.global sUnk_82DE3A0
sUnk_82DE3A0:

baserom_blob 0x2DE3A0, 0x2DE3C0

.global sUnk_82DE3C0
sUnk_82DE3C0:

baserom_blob 0x2DE3C0, 0x2DE4A0

.global sUnk_82DE4A0
sUnk_82DE4A0:

baserom_blob 0x2DE4A0, 0x2DE4C0

.global sUnk_82DE4C0
sUnk_82DE4C0:

baserom_blob 0x2DE4C0, 0x2DE4D8

.global sUnk_82DE4D8
sUnk_82DE4D8:

baserom_blob 0x2DE4D8, 0x2DE4F8

.global sUnk_82DE4F8
sUnk_82DE4F8:

baserom_blob 0x2DE4F8, 0x2DE558

.global sUnk_82DE558
sUnk_82DE558:

baserom_blob 0x2DE558, 0x2DE578

.global sUnk_82DE578
sUnk_82DE578:

baserom_blob 0x2DE578, 0x2DE598

.global sUnk_82DE598
sUnk_82DE598:

baserom_blob 0x2DE598, 0x2DE5D8

.global sUnk_82DE5D8
sUnk_82DE5D8:

baserom_blob 0x2DE5D8, 0x2DE5F8

.global sUnk_82DE5F8
sUnk_82DE5F8:

baserom_blob 0x2DE5F8, 0x2DE618

.global sFlamingWarioBluePalette
sFlamingWarioBluePalette:

baserom_blob 0x2DE618, 0x2DE658

.global sFlamingWarioGreenPalette
sFlamingWarioGreenPalette:

baserom_blob 0x2DE658, 0x2DE698

.global sFlamingWarioRedPalette
sFlamingWarioRedPalette:

baserom_blob 0x2DE698, 0x2DE6D8

.global sFlamingWarioEngulfedPalette1
sFlamingWarioEngulfedPalette1:

baserom_blob 0x2DE6D8, 0x2DE718

.global sFlamingWarioEngulfedPalette2
sFlamingWarioEngulfedPalette2:

baserom_blob 0x2DE718, 0x2DE798

.global sFlamingWarioEngulfedPalette3
sFlamingWarioEngulfedPalette3:

baserom_blob 0x2DE798, 0x2DE7D8

.global sFlamingWarioRecoveringPalette
sFlamingWarioRecoveringPalette:

baserom_blob 0x2DE7D8, 0x2DE818

.global sFrozenPalette
sFrozenPalette:

baserom_blob 0x2DE818, 0x2DE838

.global sZombieWarioPalette
sZombieWarioPalette:

baserom_blob 0x2DE838, 0x2DE878

.global sSnowmanWarioPalette
sSnowmanWarioPalette:

baserom_blob 0x2DE878, 0x2DE8B8

.global sBouncyWarioPalette
sBouncyWarioPalette:

baserom_blob 0x2DE8B8, 0x2DE918

.global sPuffyPalette
.global sUnk_82DE918
sPuffyPalette:
sUnk_82DE918:

baserom_blob 0x2DE918, 0x2DE938

.global sBatPalette
sBatPalette:

baserom_blob 0x2DE938, 0x2DEAF8

.global sMaskWarioPalette
sMaskWarioPalette:

baserom_blob 0x2DEAF8, 0x2DEB18

.global sWarioHitboxes
sWarioHitboxes:

baserom_blob 0x2DEB18, 0x2DEB60

.global sUnk_82DEB60
sUnk_82DEB60:

baserom_blob 0x2DEB60, 0x2DEBA2

.global sUnk_82DEBA2
sUnk_82DEBA2:

baserom_blob 0x2DEBA2, 0x2DEBC2

.global sHorizontalOscillationVelocity
sHorizontalOscillationVelocity:

baserom_blob 0x2DEBC2, 0x2DEBDA

.global sFlatWarioHorizontalMovement
sFlatWarioHorizontalMovement:

baserom_blob 0x2DEBDA, 0x2DEBF2

.global sFlatWarioVerticalMovement
sFlatWarioVerticalMovement:

baserom_blob 0x2DEBF2, 0x2DEC0A

.global sUnk_82DEC0A
sUnk_82DEC0A:

baserom_blob 0x2DEC0A, 0x2DEC1A

.global sUnk_82DEC1A
sUnk_82DEC1A:

baserom_blob 0x2DEC1A, 0x2DEC2A

.global sUnk_82DEC2A
sUnk_82DEC2A:

baserom_blob 0x2DEC2A, 0x2DEC2E

.global sUnk_82DEC2E
sUnk_82DEC2E:

baserom_blob 0x2DEC2E, 0x2DEC33

.global sUnk_82DEC33
sUnk_82DEC33:

baserom_blob 0x2DEC33, 0x2DEC36

.global sUnk_82DEC36
sUnk_82DEC36:

baserom_blob 0x2DEC36, 0x2DEC39

.global sUnk_82DEC39
sUnk_82DEC39:

baserom_blob 0x2DEC39, 0x2DEC3D

.global sUnk_82DEC3D
sUnk_82DEC3D:

baserom_blob 0x2DEC3D, 0x2DEC40

.global sUnk_82DEC40
sUnk_82DEC40:

baserom_blob 0x2DEC40, 0x2DEC58

.global sUnk_82DEC58
sUnk_82DEC58:

baserom_blob 0x2DEC58, 0x2DEC70

.global sWarioPoseHandlerTable
sWarioPoseHandlerTable:

baserom_blob 0x2DEC70, 0x2DECA0

.global sWarioPoseRequestFuncTable
sWarioPoseRequestFuncTable:

baserom_blob 0x2DECA0, 0x2DECD0

.global sUnk_82DECD0
sUnk_82DECD0:

baserom_blob 0x2DECD0, 0x2DED00

.global sUnk_82DED00
sUnk_82DED00:

baserom_blob 0x2DED00, 0x2DED30

.global sUnk_82DED30
sUnk_82DED30:

baserom_blob 0x2DED30, 0x2DED60

.global sUnk_82DED60
sUnk_82DED60:

baserom_blob 0x2DED60, 0x2DED90

.global sUnk_82DED90
sUnk_82DED90:

baserom_blob 0x2DED90, 0x2DEDC0

.global sWarioNormalPoseTable
sWarioNormalPoseTable:

baserom_blob 0x2DEDC0, 0x2DEEFC

.global sWarioWaterPoseTable
sWarioWaterPoseTable:

baserom_blob 0x2DEEFC, 0x2DEF3C

.global sFlamingWarioPoseTable
sFlamingWarioPoseTable:

baserom_blob 0x2DEF3C, 0x2DEF64

.global sFatWarioPoseTable
sFatWarioPoseTable:

baserom_blob 0x2DEF64, 0x2DEF90

.global sFrozenWarioPoseTable
sFrozenWarioPoseTable:

baserom_blob 0x2DEF90, 0x2DEFA0

.global sZombieWarioPoseUnk05Values
sZombieWarioPoseUnk05Values:

baserom_blob 0x2DEFA0, 0x2DEFB0

.global sZombieWarioPoseTable
sZombieWarioPoseTable:

baserom_blob 0x2DEFB0, 0x2DEFE4

.global sSnowmanWarioPoseTable
sSnowmanWarioPoseTable:

baserom_blob 0x2DEFE4, 0x2DF024

.global sBouncyWarioPoseTable
sBouncyWarioPoseTable:

baserom_blob 0x2DF024, 0x2DF04C

.global sPuffyWarioPoseTable
sPuffyWarioPoseTable:

baserom_blob 0x2DF04C, 0x2DF05C

.global sBatWarioPoseTable
sBatWarioPoseTable:

baserom_blob 0x2DF05C, 0x2DF070

.global sFlatWarioPoseTable
sFlatWarioPoseTable:

baserom_blob 0x2DF070, 0x2DF08C

.global sWarioMaskPoseTable
sWarioMaskPoseTable:

baserom_blob 0x2DF08C, 0x2DF094

@ Probably gfx?
.global sUnk_82DF094
sUnk_82DF094:

baserom_blob 0x2DF094, 0x2E0394

.global sUnk_82E0394
sUnk_82E0394:

baserom_blob 0x2E0394, 0x2E03BC

.global sWarioAfterimageFrames
sWarioAfterimageFrames:

baserom_blob 0x2E03BC, 0x2E04C4

.global sUnk_82E04C4
sUnk_82E04C4:

baserom_blob 0x2E04C4, 0x2E06BC

.global sUnk_82E06BC
sUnk_82E06BC:

baserom_blob 0x2E06BC, 0x2E09A4

.global sUnk_82E09A4
sUnk_82E09A4:

baserom_blob 0x2E09A4, 0x2E0BA8

.global sUnk_82E0BA8
sUnk_82E0BA8:

baserom_blob 0x2E0BA8, 0x2E0CD8

.global sUnk_82E0CD8
sUnk_82E0CD8:

baserom_blob 0x2E0CD8, 0x2E11E4

.global sUnk_82E11E4
sUnk_82E11E4:

baserom_blob 0x2E11E4, 0x2E126C

.global sUnk_82E126C
sUnk_82E126C:

baserom_blob 0x2E126C, 0x2E1294

.global sUnk_82E1294
sUnk_82E1294:

baserom_blob 0x2E1294, 0x2E12BC

.global sUnk_82E12BC
sUnk_82E12BC:

baserom_blob 0x2E12BC, 0x2E1304

.global sUnk_82E1304
sUnk_82E1304:

baserom_blob 0x2E1304, 0x2E1334

.global sUnk_82E1334
sUnk_82E1334:

baserom_blob 0x2E1334, 0x2E13DC

.global sUnk_82E13DC
sUnk_82E13DC:

baserom_blob 0x2E13DC, 0x2E140C

.global sUnk_82E140C
sUnk_82E140C:

baserom_blob 0x2E140C, 0x2E143C

.global sUnk_82E143C
sUnk_82E143C:

baserom_blob 0x2E143C, 0x2E149C

.global sUnk_82E149C
sUnk_82E149C:

baserom_blob 0x2E149C, 0x2E14FC

.global sUnk_82E14FC
sUnk_82E14FC:

baserom_blob 0x2E14FC, 0x2E1598

.global sUnk_82E1598
sUnk_82E1598:

baserom_blob 0x2E1598, 0x2E1658

.global sUnk_82E1658
sUnk_82E1658:

baserom_blob 0x2E1658, 0x2E1690

.global sUnk_82E1690
sUnk_82E1690:

baserom_blob 0x2E1690, 0x2E6A38

.global sUnk_82E6A38
sUnk_82E6A38:

baserom_blob 0x2E6A38, 0x2E9984

.global sUnk_82E9984
sUnk_82E9984:

baserom_blob 0x2E9984, 0x2F1200

.global sUnk_82F1200
sUnk_82F1200:

baserom_blob 0x2F1200, 0x2F12F0

.global sUnk_82F12F0
sUnk_82F12F0:

baserom_blob 0x2F12F0, 0x2F1344

.global sUnk_82F1344
sUnk_82F1344:

baserom_blob 0x2F1344, 0x2F1380

.global sUnk_82F1380
sUnk_82F1380:

baserom_blob 0x2F1380, 0x2F13EC

.global sUnk_82F13EC
sUnk_82F13EC:

baserom_blob 0x2F13EC, 0x2F1428

.global sUnk_82F1428
sUnk_82F1428:

baserom_blob 0x2F1428, 0x2F144C

.global sUnk_82F144C
sUnk_82F144C:

baserom_blob 0x2F144C, 0x2F1488

.global sUnk_82F1488
sUnk_82F1488:

baserom_blob 0x2F1488, 0x2F14AC

.global sUnk_82F14AC
sUnk_82F14AC:

baserom_blob 0x2F14AC, 0x2F14E8

.global sUnk_82F14E8
sUnk_82F14E8:

baserom_blob 0x2F14E8, 0x2F1518

.global sUnk_82F1518
sUnk_82F1518:

baserom_blob 0x2F1518, 0x2F1578

.global sUnk_82F1578
sUnk_82F1578:

baserom_blob 0x2F1578, 0x2F1BC8

.global sUnk_82F1BC8
sUnk_82F1BC8:

baserom_blob 0x2F1BC8, 0x2FBF7C

.global sUnk_82FBF7C
sUnk_82FBF7C:

baserom_blob 0x2FBF7C, 0x2FC000

.global sUnk_82FC000
sUnk_82FC000:

baserom_blob 0x2FC000, 0x2FC084

.global sUnk_82FC084
sUnk_82FC084:

baserom_blob 0x2FC084, 0x2FC0D8

.global sUnk_82FC0D8
sUnk_82FC0D8:

baserom_blob 0x2FC0D8, 0x2FC0F0

.global sUnk_82FC0F0
sUnk_82FC0F0:

baserom_blob 0x2FC0F0, 0x2FC108

.global sUnk_82FC108
sUnk_82FC108:

baserom_blob 0x2FC108, 0x2FC168

.global sUnk_82FC168
sUnk_82FC168:

baserom_blob 0x2FC168, 0x2FC1D4

.global sUnk_82FC1D4
sUnk_82FC1D4:

baserom_blob 0x2FC1D4, 0x2FC27C

.global sUnk_82FC27C
sUnk_82FC27C:

baserom_blob 0x2FC27C, 0x2FC2C4

.global sUnk_82FC2C4
sUnk_82FC2C4:

baserom_blob 0x2FC2C4, 0x2FC2F4

.global sUnk_82FC2F4
sUnk_82FC2F4:

baserom_blob 0x2FC2F4, 0x306E38

.global sUnk_8306E38
sUnk_8306E38:

baserom_blob 0x306E38, 0x306E74

.global sUnk_8306E74
sUnk_8306E74:

baserom_blob 0x306E74, 0x306EBC

.global sUnk_8306EBC
sUnk_8306EBC:

baserom_blob 0x306EBC, 0x306F04

.global sUnk_8306F04
sUnk_8306F04:

baserom_blob 0x306F04, 0x306F34

.global sUnk_8306F34
sUnk_8306F34:

baserom_blob 0x306F34, 0x306F70

.global sUnk_8306F70
sUnk_8306F70:

baserom_blob 0x306F70, 0x306FA0

.global sUnk_8306FA0
sUnk_8306FA0:

baserom_blob 0x306FA0, 0x307048

.global sUnk_8307048
sUnk_8307048:

baserom_blob 0x307048, 0x315EA4

.global sUnk_8315EA4
sUnk_8315EA4:

baserom_blob 0x315EA4, 0x315F10

.global sUnk_8315F10
sUnk_8315F10:

baserom_blob 0x315F10, 0x315FE8

.global sUnk_8315FE8
sUnk_8315FE8:

baserom_blob 0x315FE8, 0x316048

.global sUnk_8316048
sUnk_8316048:

baserom_blob 0x316048, 0x316078

.global sUnk_8316078
sUnk_8316078:

baserom_blob 0x316078, 0x316294

.global sUnk_8316294
sUnk_8316294:

baserom_blob 0x316294, 0x31651C

.global sUnk_831651C
sUnk_831651C:

baserom_blob 0x31651C, 0x316558

.global sUnk_8316558
sUnk_8316558:

baserom_blob 0x316558, 0x31663C

.global sUnk_831663C
sUnk_831663C:

baserom_blob 0x31663C, 0x3170DC

.global sUnk_83170DC
sUnk_83170DC:

baserom_blob 0x3170DC, 0x31D888

.global sUnk_831D888
sUnk_831D888:

baserom_blob 0x31D888, 0x31D8F4

.global sUnk_831D8F4
sUnk_831D8F4:

baserom_blob 0x31D8F4, 0x31D9C0

.global sUnk_831D9C0
sUnk_831D9C0:

baserom_blob 0x31D9C0, 0x32504C

.global sFlatWarioTransformingAnimation
sFlatWarioTransformingAnimation:

baserom_blob 0x32504C, 0x3250A0

.global sFlatWarioUnknown1Animation
sFlatWarioUnknown1Animation:

baserom_blob 0x3250A0, 0x3250DC

.global sFlatWarioFloatingAnimation
sFlatWarioFloatingAnimation:

baserom_blob 0x3250DC, 0x32513C

.global sFlatWarioStandingAnimation
sFlatWarioStandingAnimation:

baserom_blob 0x32513C, 0x325160

.global sFlatWarioWalkingAnimation
sFlatWarioWalkingAnimation:

baserom_blob 0x325160, 0x3251FC

.global sFlatWarioDetransformingAnimation
sFlatWarioDetransformingAnimation:

baserom_blob 0x3251FC, 0x325274

.global sFatWarioTransformingFrames
sFatWarioTransformingFrames:

baserom_blob 0x325274, 0x325370

.global sFatWarioTurningFrames
sFatWarioTurningFrames:

baserom_blob 0x325370, 0x3253A0

.global sFatWarioWalkingFrames
sFatWarioWalkingFrames:

baserom_blob 0x3253A0, 0x325424

.global sFatWarioJumpingFrames
sFatWarioJumpingFrames:

baserom_blob 0x325424, 0x325460

.global sFatWarioKillingEnemyFrames
sFatWarioKillingEnemyFrames:

baserom_blob 0x325460, 0x325484

.global sFatWarioDetransformingFrames
sFatWarioDetransformingFrames:

baserom_blob 0x325484, 0x325544

.global sFrozenTransformAnimation
sFrozenTransformAnimation:

baserom_blob 0x325544, 0x325598

.global sFrozenBonkAnimation
sFrozenBonkAnimation:

baserom_blob 0x325598, 0x331224

.global sZombieWarioWalkingFrames
sZombieWarioWalkingFrames:

baserom_blob 0x331224, 0x33126C

.global sZombieWarioEmergingFromHatFrames
sZombieWarioEmergingFromHatFrames:

baserom_blob 0x33126C, 0x3312A8

.global sZombieWarioJumpingFrames
sZombieWarioJumpingFrames:

baserom_blob 0x3312A8, 0x3312D8

.global sZombieWarioFallingThroughPlatformFrames
sZombieWarioFallingThroughPlatformFrames:

baserom_blob 0x3312D8, 0x3313F8

.global sZombieWarioLandingFrames
sZombieWarioLandingFrames:

baserom_blob 0x3313F8, 0x33144C

.global sZombieWarioHatLandingFrames
sZombieWarioHatLandingFrames:

baserom_blob 0x33144C, 0x3314A0

.global sPuffyTransformingAnimation
sPuffyTransformingAnimation:

baserom_blob 0x3314A0, 0x33150C

.global sPuffyFloatingAnimation
sPuffyFloatingAnimation:

baserom_blob 0x33150C, 0x331548

.global sPuffyHitCeilingAnimation
sPuffyHitCeilingAnimation:

baserom_blob 0x331548, 0x331620

.global sZombieWarioFallingFrames
sZombieWarioFallingFrames:

baserom_blob 0x331620, 0x331650

.global sZombieWarioHatFallingFrames
sZombieWarioHatFallingFrames:

baserom_blob 0x331650, 0x3316D4

.global sZombieWarioTouchingLightFrames
sZombieWarioTouchingLightFrames:

baserom_blob 0x3316D4, 0x33186C

.global sZombieWarioUnknown11Frames
sZombieWarioUnknown11Frames:

baserom_blob 0x33186C, 0x33189C

.global sPuffyInhalingAnimation
sPuffyInhalingAnimation:

baserom_blob 0x33189C, 0x3318D8

.global sMaskWarioTransformAnimation
sMaskWarioTransformAnimation:

baserom_blob 0x3318D8, 0x33B9E4

.global sSnowmanWarioWalkingAnimation
sSnowmanWarioWalkingAnimation:

baserom_blob 0x33B9E4, 0x33BA2C

.global sSnowmanWarioBonkAnimation
sSnowmanWarioBonkAnimation:

baserom_blob 0x33BA2C, 0x33BA74

.global sSnowmanWarioJumpingAnimation
sSnowmanWarioJumpingAnimation:

baserom_blob 0x33BA74, 0x33BAE0

.global sSnowmanWarioTransformingAnimation
sSnowmanWarioTransformingAnimation:

baserom_blob 0x33BAE0, 0x33BB10

.global sSnowmanWarioLandingAfterMidairSnowContactAnimation
sSnowmanWarioLandingAfterMidairSnowContactAnimation:

baserom_blob 0x33BB10, 0x33BBA0

.global sSnowmanWarioTurningAnimation
sSnowmanWarioTurningAnimation:

baserom_blob 0x33BBA0, 0x33BBC4

.global sSnowmanWarioRollingSmallAnimation
sSnowmanWarioRollingSmallAnimation:

baserom_blob 0x33BBC4, 0x33BC18

.global sSnowmanWarioRollingMediumAnimation
sSnowmanWarioRollingMediumAnimation:

baserom_blob 0x33BC18, 0x33BC54

.global sSnowmanWarioRollingLargeAnimation
sSnowmanWarioRollingLargeAnimation:

baserom_blob 0x33BC54, 0x33BCC0

.global sBatFlyAnimation
sBatFlyAnimation:

baserom_blob 0x33BCC0, 0x33BD14

.global sBatLandAnimation
sBatLandAnimation:

baserom_blob 0x33BD14, 0x33BD5C

.global sBatTurnAnimation
sBatTurnAnimation:

baserom_blob 0x33BD5C, 0x33BD8C

.global sBatRecoverAnimation
sBatRecoverAnimation:

baserom_blob 0x33BD8C, 0x33BE10

.global sBatTransformAnimation
sBatTransformAnimation:

baserom_blob 0x33BE10, 0x340750

.global sBouncyWarioTransformingAnimation
sBouncyWarioTransformingAnimation:

baserom_blob 0x340750, 0x340768

.global sBouncyWarioJumpingAnimation
sBouncyWarioJumpingAnimation:

baserom_blob 0x340768, 0x3407BC

.global sBouncyWarioHittingCeilingAnimation
sBouncyWarioHittingCeilingAnimation:

baserom_blob 0x3407BC, 0x34084C

.global sBouncyWarioStartingJumpAnimation
sBouncyWarioStartingJumpAnimation:

baserom_blob 0x34084C, 0x3408DC

.global sBouncyWarioFinalLandingAnimation
sBouncyWarioFinalLandingAnimation:

baserom_blob 0x3408DC, 0x340924

.global sBouncyWarioFinalBounceAnimation
sBouncyWarioFinalBounceAnimation:

baserom_blob 0x340924, 0x3409B4

.global sBouncyWarioHoppingAnimation
sBouncyWarioHoppingAnimation:

baserom_blob 0x3409B4, 0x34B0B4

.global sFlamingWarioBlueFrames
sFlamingWarioBlueFrames:

baserom_blob 0x34B0B4, 0x34B120

.global sFlamingWarioRedFrames
sFlamingWarioRedFrames:

baserom_blob 0x34B120, 0x34B15C

.global sFlamingWarioEngulfedFrames
sFlamingWarioEngulfedFrames:

baserom_blob 0x34B15C, 0x34B198

.global sFlamingWarioRecoveringFrames
sFlamingWarioRecoveringFrames:

baserom_blob 0x34B198, 0x34B264

.global sFlamingWarioGreenFrames
sFlamingWarioGreenFrames:

baserom_blob 0x34B264, 0x34F04C

.global sUnk_834F04C
sUnk_834F04C:

baserom_blob 0x34F04C, 0x34F0A0

.global sUnk_834F0A0
sUnk_834F0A0:

baserom_blob 0x34F0A0, 0x34F190

.global sUnk_834F190
sUnk_834F190:

baserom_blob 0x34F190, 0x34F1B4

.global sUnk_834F1B4
sUnk_834F1B4:

baserom_blob 0x34F1B4, 0x3528A0

.global sUnk_83528A0
sUnk_83528A0:

baserom_blob 0x3528A0, 0x352930

.global sUnk_8352930
sUnk_8352930:

baserom_blob 0x352930, 0x35299C

.global sUnk_835299C
sUnk_835299C:

baserom_blob 0x35299C, 0x3529A8
